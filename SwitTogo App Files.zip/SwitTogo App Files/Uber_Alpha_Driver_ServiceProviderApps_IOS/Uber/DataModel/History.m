//
//  History.m
//  Uber
//
//  Created by Elluminati - macbook on 27/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "History.h"

@implementation History

@synthesize random_id;
@synthesize lattitude;
@synthesize logitude;
@synthesize client_id;
@synthesize driver_id;
@synthesize time_of_pickup;
@synthesize end_lattitude;
@synthesize end_logitude;
@synthesize driver_name;
@synthesize client_name;
@synthesize amount;

#pragma mark -
#pragma mark - Init

-(id)initWithData:(NSDictionary *)dict
{
    self=[super init];
    if (self) {
        [self setData:dict];
    }
    return self;
}

#pragma mark -
#pragma mark - Methods

-(void)setData:(NSDictionary *)dict
{
    random_id=[dict objectForKey:@"random_id"];
    lattitude=[dict objectForKey:@"lattitude"];
    logitude=[dict objectForKey:@"logitude"];
    client_id=[dict objectForKey:@"client_id"];
    driver_id=[dict objectForKey:@"driver_id"];
    time_of_pickup=[dict objectForKey:@"time_of_pickup"];
    end_lattitude=[dict objectForKey:@"end_lattitude"];
    end_logitude=[dict objectForKey:@"end_logitude"];
    driver_name=[dict objectForKey:@"driver_name"];
    client_name=[dict objectForKey:@"client_name"];
    amount=[dict objectForKey:@"amount"];
}

@end
