//
//  SetETAVC.h
//  Uber
//
//  Created by Elluminati - macbook on 30/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"

@interface SetETAVC : BaseVC
{
    
}
@property(nonatomic,weak)IBOutlet UIView *viewHeaderDriver;
@property(nonatomic,weak)IBOutlet UILabel *lblRefNo;
@property(nonatomic,weak)IBOutlet UIDatePicker *datePic;

+(SetETAVC *)sharedObject;
-(IBAction)onClickOk:(id)sender;

@end
