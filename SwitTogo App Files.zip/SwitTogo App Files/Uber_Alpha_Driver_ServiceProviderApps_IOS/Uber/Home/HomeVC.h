//
//  HomeVC.h
//  Uber
//
//  Created by Elluminati - macbook on 21/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"

#import <MapKit/MapKit.h>

@interface HomeVC : BaseVC<MKMapViewDelegate>
{
    UIImageView* routeView;
	
	NSArray* routes;
	
	UIColor* lineColor;
}
@property(nonatomic,weak)IBOutlet UIView *viewHeaderDriver;
@property(nonatomic,weak)IBOutlet MKMapView *mapUser;

+(HomeVC *)sharedObject;
-(void)removeAllAnnotations;
-(void)pushRecived;

@end
