//
//  JobDoneVC.h
//  Uber
//
//  Created by Elluminati - macbook on 30/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"
#import <MapKit/MapKit.h>

@interface ReachedAtClientVC : BaseVC<MKMapViewDelegate>
{
    NSTimer *timer;
}
@property(nonatomic,weak)IBOutlet UIView *viewHeaderDriver;

@property(nonatomic,weak)IBOutlet UILabel *lblTime;
@property(nonatomic,weak)IBOutlet UILabel *lblRefNo;
@property(nonatomic,weak)IBOutlet UILabel *lblClientName;
@property(nonatomic,weak)IBOutlet UILabel *lblClientNo;

@property(nonatomic,weak)IBOutlet UIView *ViewDetail;
@property(nonatomic,weak)IBOutlet MKMapView *ViewMap;

+(ReachedAtClientVC *)sharedObject;
-(IBAction)onClickReachedAtClient:(id)sender;
-(IBAction)onClickMapView:(id)sender;
-(IBAction)onClickDetailView:(id)sender;
-(IBAction)onClickClientContact:(id)sender;
-(IBAction)onClickOperatorContact:(id)sender;
@end
