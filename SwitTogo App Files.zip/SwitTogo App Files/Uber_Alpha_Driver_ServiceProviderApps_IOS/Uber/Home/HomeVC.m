//
//  HomeVC.m
//  Uber
//
//  Created by Elluminati - macbook on 21/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "HomeVC.h"
#import "FooterView.h"
#import "SetETAVC.h"
#import "JobDoneVC.h"
#import "ReachedAtClientVC.h"
#import "RegexKitLite.h"
#import "Place.h"
#import "PlaceMark.h"


@interface HomeVC ()

@end

@implementation HomeVC

#pragma mark -
#pragma mark - Init

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title=@"Jobs";
    }
    return self;
}

+(HomeVC *)sharedObject
{
    static HomeVC *obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[HomeVC alloc] initWithNibName:@"HomeVC" bundle:nil];
    });
    return obj;
}

#pragma mark -
#pragma mark - ViewLife Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.titleView=self.viewHeaderDriver;
    routeView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.mapUser.frame.size.width, self.mapUser.frame.size.height)];
    routeView.userInteractionEnabled = NO;
    [self.mapUser addSubview:routeView];
    self.mapUser.delegate=self;
    lineColor = [UIColor redColor];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationItem setHidesBackButton:YES];
    [self pushRecived];
}

#pragma mark -
#pragma mark - Methods

-(void)pushRecived
{
    [self setDriverPushView];
}

-(void)setDriverPushView
{
    if ([[DriverAssignment sharedObject]isActiveJob])
    {
        if ([[DriverAssignment sharedObject]isETAset])
        {
            if ([[DriverAssignment sharedObject] isReachedAtClient])
            {
                [super gotoView:[JobDoneVC sharedObject]];
            }
            else{
                [super gotoView:[ReachedAtClientVC sharedObject]];
            }
        }
        else{
            if ([[DriverAssignment sharedObject]isOnETA])
            {
                [super gotoView:[SetETAVC sharedObject]];
            }
            else{
                if ([DriverAssignment sharedObject].pushDriverID==PushDriverIdAssignRequest)
                {
                    Place* home = [[Place alloc] init];
                    home.name = [DriverAssignment sharedObject].random_id;
                    home.description = @"";
                    home.latitude = 22.0;
                    home.longitude = 78.0;
                    home.latitude = [[DriverAssignment sharedObject].lattitude doubleValue];
                    home.longitude = [[DriverAssignment sharedObject].logitude doubleValue];
                    home.isFrom=YES;
                    
                    Place* end = [[Place alloc] init];
                    end.name = [DriverAssignment sharedObject].random_id;
                    end.description = @"";
                    end.latitude=22.50;
                    end.longitude=78.50;
                    end.latitude = [[DriverAssignment sharedObject].end_lattitude doubleValue];
                    end.longitude = [[DriverAssignment sharedObject].end_logitude doubleValue];
                    end.isFrom=NO;
                    [self showRouteFrom:home To:end];
                    
                }
            }
        }
    }
}

-(void)removeAllAnnotations
{
    [self.mapUser removeAnnotations:[self.mapUser annotations]];
}

-(void) showRouteFrom: (Place *) pickUpFrom To:(Place *)pickUpTo
{
    [self.mapUser removeAnnotations:[self.mapUser annotations]];
    
    
	PlaceMark* markPickUp = [[PlaceMark alloc] initWithPlace:pickUpFrom];
	[self.mapUser addAnnotation:markPickUp];
    PlaceMark* PickUp = [[PlaceMark alloc] initWithPlace:pickUpTo];
	[self.mapUser addAnnotation:PickUp];
    PlaceMark* from = [[PlaceMark alloc] initWithPlace:pickUpFrom];
	PlaceMark* to = [[PlaceMark alloc] initWithPlace:pickUpTo];
    
    routes = [self calculateRoutesFrom:from.coordinate to:to.coordinate];
	
	[self updateRouteView];
    if([DriverAssignment sharedObject].isZoom==NO)
        [self centerMap];
    
}
-(NSMutableArray *)decodePolyLine: (NSMutableString *)encoded {
	[encoded replaceOccurrencesOfString:@"\\\\" withString:@"\\"
								options:NSLiteralSearch
								  range:NSMakeRange(0, [encoded length])];
	NSInteger len = [encoded length];
	NSInteger index = 0;
	NSMutableArray *array = [[NSMutableArray alloc] init];
	NSInteger lat=0;
	NSInteger lng=0;
	while (index < len) {
		NSInteger b;
		NSInteger shift = 0;
		NSInteger result = 0;
		do {
			b = [encoded characterAtIndex:index++] - 63;
			result |= (b & 0x1f) << shift;
			shift += 5;
		} while (b >= 0x20);
		NSInteger dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
		lat += dlat;
		shift = 0;
		result = 0;
		do {
			b = [encoded characterAtIndex:index++] - 63;
			result |= (b & 0x1f) << shift;
			shift += 5;
		} while (b >= 0x20);
		NSInteger dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
		lng += dlng;
		NSNumber *latitude = [[NSNumber alloc] initWithFloat:lat * 1e-5];
		NSNumber *longitude = [[NSNumber alloc] initWithFloat:lng * 1e-5];
		printf("[%f,", [latitude doubleValue]);
		printf("%f]", [longitude doubleValue]);
		CLLocation *loc = [[CLLocation alloc] initWithLatitude:[latitude floatValue] longitude:[longitude floatValue]];
		[array addObject:loc];
	}
	
	return array;
}

-(NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) f to: (CLLocationCoordinate2D) t {
	NSString* saddr = [NSString stringWithFormat:@"%f,%f", f.latitude, f.longitude];
	NSString* daddr = [NSString stringWithFormat:@"%f,%f", t.latitude, t.longitude];
	
	NSString* apiUrlStr = [NSString stringWithFormat:@"http://maps.google.com/maps?output=dragdir&saddr=%@&daddr=%@", saddr, daddr];
	NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];
	NSLog(@"api url: %@", apiUrl);
	NSError *error;
    NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl encoding:NSASCIIStringEncoding error:&error];
    
    //NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl];
    
    
	NSString* encodedPoints = [apiResponse stringByMatching:@"points:\\\"([^\\\"]*)\\\"" capture:1L];
	
	return [self decodePolyLine:[encodedPoints mutableCopy]];
}

-(void) centerMap {
    [DriverAssignment sharedObject].isZoom=YES;
	MKCoordinateRegion region;
    
	CLLocationDegrees maxLat = -90;
	CLLocationDegrees maxLon = -180;
	CLLocationDegrees minLat = 90;
	CLLocationDegrees minLon = 180;
	for(int idx = 0; idx < routes.count; idx++)
	{
		CLLocation* currentLocation = [routes objectAtIndex:idx];
		if(currentLocation.coordinate.latitude > maxLat)
			maxLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.latitude < minLat)
			minLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.longitude > maxLon)
			maxLon = currentLocation.coordinate.longitude;
		if(currentLocation.coordinate.longitude < minLon)
			minLon = currentLocation.coordinate.longitude;
	}
	region.center.latitude     = (maxLat + minLat) / 2;
	region.center.longitude    = (maxLon + minLon) / 2;
	region.span.latitudeDelta  = (maxLat - minLat)+0.01;
	region.span.longitudeDelta = (maxLon - minLon)+0.01;
	
	[self.mapUser setRegion:region animated:YES];
}
-(void) updateRouteView
{
	CGContextRef context = 	CGBitmapContextCreate(nil,
												  routeView.frame.size.width,
												  routeView.frame.size.height,
												  8,
												  4 * routeView.frame.size.width,
												  CGColorSpaceCreateDeviceRGB(),
												  (CGBitmapInfo)kCGImageAlphaPremultipliedLast);
	
	CGContextSetStrokeColorWithColor(context, lineColor.CGColor);
	CGContextSetRGBFillColor(context, 0.0, 0.0, 1.0, 1.0);
	CGContextSetLineWidth(context, 3.0);
	
	for(int i = 0; i < routes.count; i++) {
		CLLocation* location = [routes objectAtIndex:i];
		CGPoint point = [self.mapUser convertCoordinate:location.coordinate toPointToView:routeView];
		
		if(i == 0) {
			CGContextMoveToPoint(context, point.x, routeView.frame.size.height - point.y);
		} else {
			CGContextAddLineToPoint(context, point.x, routeView.frame.size.height - point.y);
		}
	}
	
	CGContextStrokePath(context);
	
	CGImageRef image = CGBitmapContextCreateImage(context);
	UIImage* img = [UIImage imageWithCGImage:image];
	
	routeView.image = img;
	CGContextRelease(context);
    
}

#pragma mark -
#pragma mark - Mapview Delegate

- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
	routeView.hidden = YES;
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
	[self updateRouteView];
	routeView.hidden = NO;
	[routeView setNeedsDisplay];
}

- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
    PlaceMark *place=(PlaceMark *)annotation;
    MKPinAnnotationView *annot=[[MKPinAnnotationView alloc] init];
    if (place.place.isFrom)
    {
        annot.pinColor=MKPinAnnotationColorRed;
    }
    else
    {
         annot.pinColor=MKPinAnnotationColorGreen;
    }
    if (![place.place.name isEqualToString:@"It's me"])
    {
        UIButton *btnSet=[UIButton buttonWithType:UIButtonTypeContactAdd];
        [btnSet addTarget:self action:@selector(onClicksetETA:) forControlEvents:UIControlEventTouchUpInside];
        annot.rightCalloutAccessoryView =btnSet;
    }
    annot.canShowCallout = YES;
    return annot;
}
-(void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
}
-(void)onClicksetETA:(id)sender
{
    [[DriverAssignment sharedObject]setIsOnETA:YES];
    [super gotoView:[SetETAVC sharedObject]];
}
- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
    
}

#pragma mark -
#pragma mark - Memory Mgmt

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
