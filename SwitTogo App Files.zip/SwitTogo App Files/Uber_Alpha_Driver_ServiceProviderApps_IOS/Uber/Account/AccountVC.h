//
//  AccountVC.h
//  Uber
//
//  Created by Elluminati - macbook on 23/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"

@interface AccountVC : BaseVC<UITextFieldDelegate>
{
    
}
+(AccountVC *)sharedObject;

@property(nonatomic,weak)IBOutlet UIView *viewHeader;

@property(nonatomic,weak)IBOutlet UIScrollView *scrAcc;

@property(nonatomic,weak)IBOutlet UITextField *txtUserName;
@property(nonatomic,weak)IBOutlet UITextField *txtSex;
@property(nonatomic,weak)IBOutlet UITextField *txtEmailID;
@property(nonatomic,weak)IBOutlet UITextField *txtDOB;
@property(nonatomic,weak)IBOutlet UITextField *txtMoNo;

-(IBAction)onClickHistory:(id)sender;
-(IBAction)onClickUpdate:(id)sender;
-(IBAction)onClickLogout:(id)sender;

@end
