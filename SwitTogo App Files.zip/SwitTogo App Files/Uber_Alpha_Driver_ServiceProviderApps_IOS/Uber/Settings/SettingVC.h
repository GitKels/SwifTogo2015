//
//  SettingVC.h
//  Uber
//
//  Created by Elluminati - macbook on 23/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"

@interface SettingVC : BaseVC
{
    DriverStat driverStat;
}
@property(nonatomic,weak)IBOutlet UIView *viewHeaderDriver;
@property(nonatomic,weak)IBOutlet UIImageView *imgBG;

@property(nonatomic,weak)IBOutlet UIImageView *imgAvb;
+(SettingVC *)sharedObject;

@end
