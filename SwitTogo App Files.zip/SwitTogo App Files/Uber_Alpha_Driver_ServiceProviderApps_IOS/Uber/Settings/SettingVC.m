//
//  SettingVC.m
//  Uber
//
//  Created by Elluminati - macbook on 23/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "SettingVC.h"

@interface SettingVC ()

@end

@implementation SettingVC

#pragma mark -
#pragma mark - Init

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title=@"Settings";
    }
    return self;
}

+(SettingVC *)sharedObject
{
    static SettingVC *obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[SettingVC alloc] initWithNibName:@"SettingVC" bundle:nil];
    });
    return obj;
}

#pragma mark -
#pragma mark - ViewLife Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.imgBG.image=[UIImage imageNamed:@"bg_settings"];
    self.navigationItem.titleView=self.viewHeaderDriver;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationItem setHidesBackButton:YES];
    [self setData];
}

#pragma mark -
#pragma mark - Actions

-(IBAction)onClickAvb:(id)sender
{
    //self.imgAvb.image=[UIImage imageNamed:@"driver_availablity_yes"];
    [self changeStat];
}

-(IBAction)onClickNotAvb:(id)sender
{
    //self.imgAvb.image=[UIImage imageNamed:@"driver_availablity_no"];
    [self changeStat];
}

#pragma mark -
#pragma mark - Methods

-(void)setData
{
    if ([[User currentUser].is_busy intValue]==0)
    {
        driverStat=DriverStatAvailable;
        self.imgAvb.image=[UIImage imageNamed:@"driver_availablity_yes"];
    }
    else{
        driverStat=DriverStatNotAvailable;
        self.imgAvb.image=[UIImage imageNamed:@"driver_availablity_no"];
    }
}

-(void)changeStat
{
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setObject:[User currentUser].driver_id forKey:PARAM_DRIVER_ID];
    
    [[AppDelegate sharedAppDelegate]showHUDLoadingView:@""];
    
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    [afn getDataFromPath:FILE_SET_DRIVER_STAT withParamData:dictParam withBlock:^(id response, NSError *error)
    {
        [[AppDelegate sharedAppDelegate]hideHUDLoadingView];
        if (response)
        {
            NSMutableDictionary *dict=[response objectForKey:WS_UBER_ALPHA];
            if ([[dict objectForKey:WS_STATUS]isEqualToString:WS_STATUS_SUCCESS])
            {
                [[AppDelegate sharedAppDelegate]showToastMessage:[dict objectForKey:WS_MESSAGE]];
                [[User currentUser]changeDriverStat:dict];
                [self setData];
            }
            else{
                [[AppDelegate sharedAppDelegate]showToastMessage:[dict objectForKey:WS_MESSAGE]];
            }
        }
        else{
            [[AppDelegate sharedAppDelegate]showToastMessage:@"Server error, please try again"];
        }
    }];
}

#pragma mark -
#pragma mark - Memory Mgmt

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
