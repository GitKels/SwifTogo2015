//
//  RegisterVC.h
//  Uber
//
//  Created by Elluminati - macbook on 23/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"

@class Country;
@interface RegisterVC : BaseVC<UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate>
{
    Gender gender;
    NSMutableArray *arrCountry;
    Country *selectedCountry;
}
@property(nonatomic,weak)IBOutlet UIScrollView *scrReg;

@property(nonatomic,weak)IBOutlet UITextField *txtUserName;
@property(nonatomic,weak)IBOutlet UITextField *txtSex;
@property(nonatomic,weak)IBOutlet UITextField *txtEmailID;
@property(nonatomic,weak)IBOutlet UITextField *txtPsw;
@property(nonatomic,weak)IBOutlet UITextField *txtDOB;
@property(nonatomic,weak)IBOutlet UITextField *txtMoNo;

@property(nonatomic,weak)IBOutlet UILabel *lblRefNo;
@property(nonatomic,weak)IBOutlet UITextField *txtRefNo;
@property(nonatomic,weak)IBOutlet UIImageView *imgRefNo;

@property(nonatomic,weak)IBOutlet UIView *viewPickDOB;
@property(nonatomic,weak)IBOutlet UIDatePicker *pickDOB;

@property(nonatomic,weak)IBOutlet UIView *viewCountryCode;
@property(nonatomic,weak)IBOutlet UIPickerView *pickCountryCode;
@property(nonatomic,weak)IBOutlet UITextField *txtCountryCode;

-(IBAction)onClickRegister:(id)sender;
-(IBAction)onClickDone:(id)sender;
-(IBAction)onClickDoneContryCode:(id)sender;

@end
