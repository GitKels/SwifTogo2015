<!--/ END Template Header -->

<!-- START Template Sidebar (Left) -->
<?php echo $this->load->view('sidebar'); ?>
<!--/ END Template Sidebar (Left) -->

<!-- START Template Main -->
<section id="main" role="main">
    <!-- START Template Container <div class="container-fluid"> -->
    <div class="container">
        <div class="row tab-content-caption">

            <div class="col-md-4 big-text">
                <p>Job List</p>
            </div>
            <div class="col-md-6 notification-detail">
                <p>All the Users</p>
            </div>

        </div>
        <div class="row editable-options">
            <div class="container">
                <div class="col-md-1">
                    <a href="only_jobcompleted"><button type='button' class='btn btn-green'>Job Complete</button></a>

                </div>
                <div class="col-md-1">

                    <a href="not_jobcompleted"><button type='button' class='btn btn-green'>Incomplete</button></a>

                </div>



            </div>
        </div>

        <!-- Page Header -->
        <!--<div class="page-header page-header-block">
            <div class="page-header-section">
                <h4 class="title semibold">Job List</h4>
            </div>
        </div>-->
        <!-- Page Header -->

        <!-- START row -->
        <div class="row">
            <div class="col-md-12">
                <!-- START panel -->

                <!--/ panel toolbar wrapper -->


                <!-- panel body with collapse capabale -->
                <div class="table-responsive panel-collapse pull out">
                    <table class="table table-bordered table-hover" id="table1">
                        <thead>
                            <tr>
                                <td width="20" class="text-center">Id</td>
                                <td width="80" class="text-center">Request Id</td>
                                <td id="driver_arrange"><?php echo DRIVER; ?> Name <i class=""></i></td>
                                <td id="client_arrange"><?php echo CLIENT; ?> Name <i class=""></i></td>
                                <td >Request Time</td>

                                <td width="100">Pickup Time</td>
                                <td id="complete_arrange">Status <i class=""></i></td>
                                <td width="50"></td>
                            </tr>
                        </thead>
                        <tbody id="job_data">
                            <?php
                            $base = base_url();

                            function mili_to_time($milis) {
                                $hours = (int) (($milis / (1000 * 60 * 60)) % 24);

                                $minutes = (int) (($milis / (1000 * 60)) % 60);
                                $seconds = (int) ($milis / 1000) % 60;
                                $time = $hours . ":" . $minutes . ":" . $seconds;
                                return $time;
                            }

                            foreach ($users_list as $user) {
                                $root_id = $user->random_id;
                                $status = $user->complete_status;
                                if ($status == '1') {
                                    $status = "Completed";
                                    $root_id = "<a href='" . $base . "index.php/users/detail_history?id=" . $root_id . "' alt='link to map'>" . $root_id . "</a>";
                                    $button_link = "\"alert('Sorry, you can not delete completed request.')\"";
                                } else {
                                    $status = "Incomplete";
                                    $root_id = "<a href='" . $base . "index.php/users/go_to_map?id=" . $user->random_id . "' alt='link to map'>" . $root_id . "</a>";
                                    $button_link = "\"location.href='" . $base . "index.php/users/delete_request?id=" . $user->random_id . "'\"";
                                }
                                $driver = $user->drivername;
                                if (!isset($driver) || empty($driver)) {
                                    $driver = "<span style='color:#FF0000;'>Not Assigned</span>";
                                } else {
                                    $driver = $user->drivername;
                                }
                                $mil = mili_to_time($user->time_of_pickup);
                                $dat = date('Y-m-d H:i:s', strtotime($user->request_time));
                                echo "<tr>"
                                . "<td> $user->request_id </td>"
                                . "<td>" . $root_id . "</td>"
                                . "<td>" . $driver . "</td>"
                                . "<td>" . $user->clientname . "</td>"
                                . "<td>" . $dat . "</td>"
                                . "<td>" . $mil . "</td>"
                                . "<td>" . $status . "</td>"
                                . "<td class='text-center'>"
                                . "<!-- button toolbar -->"
                                . "<div class='toolbar'>"
                                . "<div class='btn-group'>"
                                . "<button type='button' value='" . $user->client_id . "' name='cid' class='btn btn-nothing' onclick=" . $button_link . ">Delete</button>"
                                . "</div>"
                                . "</div>"
                                . "<!--/ button toolbar -->"
                                . "</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <!--/ panel body with collapse capabale -->
            </div>
        </div>
    </div>
    <!--/ END row -->


</div>
<!--/ END Template Container -->

<!-- START To Top Scroller -->
<a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
<!--/ END To Top Scroller -->
</section>
<!--/ END Template Main -->
<script type="text/javascript">
    $('#all_jobs').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
    
    var num = 1;
    var num1 = 1;
    var num2 = 1;
    $('#driver_arrange').css('cursor', 'pointer');
    $('#driver_arrange').click(function() {
        $('#client_arrange > i').removeClass('icon-arrow-up');
        $('#client_arrange > i').removeClass('icon-arrow-down');
        $('#complete_arrange > i').removeClass('icon-arrow-up');
        $('#complete_arrange > i').removeClass('icon-arrow-down');
        if (num % 2 == 0) {
            $('#driver_arrange > i').removeClass('icon-arrow-up');
            $('#driver_arrange > i').addClass('icon-arrow-down');
            $('#job_data').load('<?php echo base_url(); ?>index.php/users/driver_job_arrange?arrange=DESC').fadeIn("slow");
        } else {
            $('#driver_arrange > i').removeClass('icon-arrow-down');
            $('#driver_arrange > i').addClass('icon-arrow-up');
            $('#job_data').load('<?php echo base_url(); ?>index.php/users/driver_job_arrange?arrange=ASC').fadeIn("slow");
        }
        num++;
    });

    $('#client_arrange').css('cursor', 'pointer');
    $('#client_arrange').click(function() {
        $('#driver_arrange > i').removeClass('icon-arrow-up');
        $('#driver_arrange > i').removeClass('icon-arrow-down');
        $('#complete_arrange > i').removeClass('icon-arrow-up');
        $('#complete_arrange > i').removeClass('icon-arrow-down');
        if (num1 % 2 == 0) {
            $('#client_arrange > i').removeClass('icon-arrow-up');
            $('#client_arrange > i').addClass('icon-arrow-down');
            $('#job_data').load('<?php echo base_url(); ?>index.php/users/user_job_arrange?arrange=DESC').fadeIn("slow");
        } else {
            $('#client_arrange > i').removeClass('icon-arrow-down');
            $('#client_arrange > i').addClass('icon-arrow-up');
            $('#job_data').load('<?php echo base_url(); ?>index.php/users/user_job_arrange?arrange=ASC').fadeIn("slow");
        }
        num1++;
    });

    $('#complete_arrange').css('cursor', 'pointer');
    $('#complete_arrange').click(function() {
        $('#client_arrange > i').removeClass('icon-arrow-up');
        $('#client_arrange > i').removeClass('icon-arrow-down');
        $('#driver_arrange > i').removeClass('icon-arrow-up');
        $('#driver_arrange > i').removeClass('icon-arrow-down');
        if (num2 % 2 == 0) {
            $('#complete_arrange > i').removeClass('icon-arrow-up');
            $('#complete_arrange > i').addClass('icon-arrow-down');
            $('#job_data').load('<?php echo base_url(); ?>index.php/users/complete_arrange?arrange=DESC').fadeIn("slow");
        } else {
            $('#complete_arrange > i').removeClass('icon-arrow-down');
            $('#complete_arrange > i').addClass('icon-arrow-up');
            $('#job_data').load('<?php echo base_url(); ?>index.php/users/complete_arrange?arrange=ASC').fadeIn("slow");
        }
        num2++;
    });
</script>