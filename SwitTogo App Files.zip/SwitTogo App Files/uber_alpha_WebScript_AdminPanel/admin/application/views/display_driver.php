


<!--/ END Template Header -->

<!-- START Template Sidebar (Left) -->
<?php echo $this->load->view('sidebar'); ?>
<!--/ END Template Sidebar (Left) -->

<!-- START Template Main -->
<section id="main" role="main">
    <div class="row tab-content-caption">
          <div class="container">
            <div class="col-md-4 big-text">
              <p>Requests on MAP </p>
            </div>
            <div class="col-md-6 notification-detail">
              <p><?php echo DRIVER; ?> list</p>
            </div>
          </div>
        </div>
      <!-- old code --> 
    
    <!-- START Template Container <div class="container-fluid"> -->
    <div class="container">
        <br>
        <br>
        <!-- Page Header -->
    <!--     <div class="page-header page-header-block">
            <div class="page-header-section">
                <h4 class="title semibold">Requests on MAP <?php echo DRIVER; ?> list</h4>
            </div>
        </div> -->
        <!-- Page Header -->
        <!-- START row -->
        <div class="row">
            <div class="col-md-12">
                <!-- START panel <div class="panel panel-primary"> -->
                <div>
                    <!-- panel heading/header <div class="panel-heading"> -->
                    
                    <!--/ panel heading/header -->
                    <!-- panel toolbar wrapper -->
                    <?php echo form_open('data_controller/delete_driver'); ?>
                    <div class="panel-toolbar-wrapper pl0 pt5 pb5">
                        <!--<div class="panel-toolbar pl10">
                            <div class="checkbox custom-checkbox pull-left">  
                                <input type="checkbox" id="customcheckbox" value="1" data-toggle="checkall" data-target="#table1">  
                                <label for="customcheckbox">&nbsp;&nbsp;Select all</label>  
                                <a href="driver_aprove"><button type='button' class='btn btn-sm btn-info'>Aprove</button></a>
                                <a href="driver_pendding"><button type='button' class='btn btn-sm btn-info'>Pendding</button></a>
                            </div>
                        </div>
                        <div class="panel-toolbar text-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-default"><i class="ico-upload22"></i></button>
                                <button type="button" class="btn btn-sm btn-default"><i class="ico-archive2"></i></button>
                            </div>

                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are Your Sure Dlete It ?')"><i class="ico-remove3"></i></button>
                        </div>-->
                    </div>
                    <!--/ panel toolbar wrapper -->


                    <!-- panel body with collapse capabale -->
                    <div class="table-responsive panel-collapse pull out">
                        <div id="map" style="width: 100%; height: 500px"></div>
                    </div>
                    <!--/ panel body with collapse capabale -->
                </div>
            </div>
        </div>
        <!--/ END row -->


    </div>
    <!--/ END Template Container -->

    <!-- START To Top Scroller -->
    <a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
    <!--/ END To Top Scroller -->
</section>



<!--/ END Template Main -->

