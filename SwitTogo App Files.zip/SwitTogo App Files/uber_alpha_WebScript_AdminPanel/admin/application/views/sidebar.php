    <div class="row second-nav">
    <div class="container">
      <ul class="nav nav-pills">
        <li id="home" title="Home">
            <?php echo anchor('welcome', '<img src="'.  base_url().'/public/image/menu_buttons/home_button.png"/>'); ?>

            </li>
        <li id="cli_requ" title="<?php echo CLIENT; ?> Requests">
            <?php echo anchor('users/client_requests', '<img src="'.  base_url().'/public/image/menu_buttons/user_requests.png"/>'); ?>

            </li>
        <li id="all_drivers" title="<?php echo DRIVER; ?>s">
            
            <?php echo anchor('users/driver', '<img src="'.  base_url().'/public/image/menu_buttons/driver_icon.png"/>'); ?>
            </li>
        <li id="all_clients" title="<?php echo CLIENT; ?>s">
            <?php echo anchor('users', '<img src="'.  base_url().'/public/image/menu_buttons/user_icon.png"/>'); ?>
            
            </li>
        <li id="all_feedbacks" title="<?php echo CLIENT; ?> Feedbacks">
            <?php echo anchor('users/feedback', '<img src="'.  base_url().'/public/image/menu_buttons/feedback_icon.png"/>'); ?>

            </li>
        <li id="all_jobs" title="All Jobs">
            <?php echo anchor('users/jobcompleted', '<img src="'.  base_url().'/public/image/menu_buttons/all_jobs.png"/>'); ?>

            </li>
        
            
            <li id="change_oper" title="Change Operator">
                <?php echo anchor('operator', '<img src="'.  base_url().'/public/image/menu_buttons/change_operator_icon.png"/>'); ?>

            </li>
            <li id="change_about" title="Change About Us">
                <?php echo anchor('users/about_us', '<img src="'.  base_url().'/public/image/menu_buttons/change_about_us_icon.png"/>'); ?>

            </li>
            <li id="change_setting" title="Seattings">
                <?php echo anchor('settings', '<img src="'.  base_url().'/public/image/menu_buttons/seattings_icon.png"/>'); ?>

            </li>
            
            
            
            
            
            
            
            <!--
            <li><a href="#option7" data-toggle="tab"><i class="icon-phone"></i></a></li>
        <li><a href="#option8" data-toggle="tab"><i class="icon-file"></i></a></li>
        <li><a href="#option9" data-toggle="tab"><i class="icon-list-ul"></i></a></li> -->
      </ul>
    </div>
  </div>
