<?php echo $this->load->view('sidebar'); ?>
<section id="main" role="main">
    <div class="container">
        <div class="row tab-content-caption">
            <div class="container">
                <div class="col-md-4 big-text">
                    <p><?php echo CLIENT; ?>s List</p>
                </div>
                <div class="col-md-6 notification-detail">
                    <p>All the Users</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="row editable-options">
                <?php echo form_open('data_controller/delete_user'); ?>
                <div class="container">
                    <div class="col-md-2">
                        <input type="checkbox" id="customcheckbox" value="1" data-toggle="checkall" data-target="#table1">  
                        <label for="customcheckbox">&nbsp;&nbsp;Select all</label>
                    </div>
                    <div class="col-md-1">
                    </div>
                    <div class="col-md-1">
                    </div>
                    <div class="col-md-5">

                    </div>
                    <div class="col-md-3 options-right-icon">
                        <i class="icon-upload"></i><i class="icon-archive"></i>
                        <span onclick="return confirm('Are Your Sure Dlete It ?')"><i class="icon-trash"></i></span>
                    </div>
                </div>
            </div>
            <div class="table-responsive panel-collapse pull out">
                <table class="table table-bordered table-hover" id="table1">
                    <thead>
                        <tr>
                            <td width="3%" class="text-center"><i class="icon-arrow-down"></i></td>

                            <td id="client_arrange">Name <i class=""></i></td>
                            <td>Email</td>
                            <td>Phone</td>
                            <td>Gender</td>

                            <td >Requests</td>
                            <td width="100">Device</td>

                            <td width="50">History</td>
                            <td width="50"></td>
                        </tr>
                    </thead>
                    <tbody id="client_data">
                        <?php
                        $base = base_url();
                        foreach ($users_list as $user) {
                            $devicetype = $user->device_type;
                            if ($devicetype == 1) {
                                $devicetype = "iPhone";
                            } else {
                                $devicetype = "Android";
                            }
                            echo "<tr>"
                            . "<td>"
                            . "<input type='checkbox' id='customcheckbox1[]' name='customcheckbox1[]' value=' $user->client_id  ' data-toggle='selectrow' data-target='tr' data-contextual='success'>"
                            . "<label for='customcheckbox1'></label>"
                            . "</td>"
                            . "<td>" . $user->name . "</td>"
                            . "<td>" . $user->email . "</td>"
                            . "<td>" . $user->country_code . $user->contact . "</td>"
                            . "<td>" . $user->gender . "</td>"
                            . "<td>" . $user->total_trips . "</td>"
                            . "<td>" . $devicetype . "</td>"
                            . "<input type='hidden' name='eid' value='" . $user->client_id . "'>"
                            . "<td class='text-center'>"
                            . "<button type='button' class='btn btn-green' onclick=\"location.href='" . $base . "index.php/users/user_history?id=" . $user->client_id . "'\">History</button>"
                            . "</td>"
                            . "<td class='text-center'>"
                            . "<!-- button toolbar -->"
                            . "<div class='toolbar'>"
                            . "<div class='btn-group'>"
                            . "<button type='submit' value='" . $user->client_id . "' name='cid' class='btn btn-nothing' onclick=\"return confirm('Are Your Sure Dlete It ?')\">Delete</button>"
                            . "</div>"
                            . "</div>"
                            . "<!--/ button toolbar -->"
                            . "</td>"
                            . "</form>"
                            . "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


</div>
<a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
</section>
<script type="text/javascript">
    $('#all_clients').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
    
    var num = 1;
    $('#client_arrange').css('cursor', 'pointer');
    $('#client_arrange').click(function() {
        if (num % 2 == 0) {
            $('#client_arrange > i').removeClass('icon-arrow-up');
            $('#client_arrange > i').addClass('icon-arrow-down');
            $('#client_data').load('<?php echo base_url(); ?>index.php/users/users_arrange?arrange=DESC').fadeIn("slow");
        } else {
            $('#client_arrange > i').removeClass('icon-arrow-down');
            $('#client_arrange > i').addClass('icon-arrow-up');
            $('#client_data').load('<?php echo base_url(); ?>index.php/users/users_arrange?arrange=ASC').fadeIn("slow");
        }
        num++;
    });
</script>
