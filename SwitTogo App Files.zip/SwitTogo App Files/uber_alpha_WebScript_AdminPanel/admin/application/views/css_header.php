<html>
    <!-- START Head -->
    <head>
        <!-- START META SECTION -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo PAGE_TITLE; ?> - Web Admin</title>
        <meta name="author" content="pampersdry.info">
        <meta name="description" content="Adminre is a clean and flat admin theme build with Slim framework and Twig template engine.">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
        
        <link rel="icon" type="image/png" href="<?php echo base_url(); ?>/public/image/favicon.png">
        <link rel="icon" type="image/ico" href="<?php echo base_url(); ?>/public/image/favicon.ico">
        
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="image/touch/apple-touch-icon-144x144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="image/touch/apple-touch-icon-114x114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="image/touch/apple-touch-icon-72x72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="image/touch/apple-touch-icon-57x57-precomposed.png">
        <link rel="shortcut icon" href="image/touch/apple-touch-icon.png">
        <!--/ END META SECTION -->

        <!-- START STYLESHEETS -->
        <!-- Plugins stylesheet : optional -->

        <!--/ Plugins stylesheet -->

        <!-- Application stylesheet : mandatory -->
        <!--<link rel="stylesheet" href="<?php echo base_url(); ?>/public/library/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/layout.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/uielement.min.css">
        <link rel="stylesheet"href="<?php echo base_url(); ?>/public/plugins/datatables/css/jquery.datatables.min.css">-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/responsive-style.css">
        
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
        <!--/ Application stylesheet -->
        <!-- END STYLESHEETS -->

        <!-- START JAVASCRIPT SECTION - Load only modernizr script here -->
        <script src="<?php echo base_url(); ?>/public/library/modernizr/js/modernizr.min.js"></script>
        <!--/ END JAVASCRIPT SECTION -->
    </head>
    <!--/ END Head -->

    <!-- START Body -->
    <body>