

<!--/ END Template Header -->

<!-- START Template Sidebar (Left) -->
<?php echo $this->load->view('sidebar'); ?>
<!--/ END Template Sidebar (Left) -->

<!-- START Template Main -->
<section id="main" role="main">
    <!-- START Template Container -->
    <div class="container">
        <!-- Page Header -->
        <div class="row tab-content-caption">
            <div class="container">
                <div class="col-md-4 big-text">
                    <p><?php echo DRIVER; ?> History</p>
                </div>
                <div class="col-md-6 notification-detail">
                    <p></p>
                </div>
            </div>
        </div>

        <!-- Page Header -->

        <!-- START row -->
        <div class="row">
            <div class="col-md-12">
                <!-- START panel -->
                <div>
                    <!-- panel heading/header -->

                    <!--/ panel heading/header -->
                    <!-- panel toolbar wrapper -->
                    <?php echo form_open('data_controller/delete_driver'); ?>
                    <!--/ panel toolbar wrapper -->


                    <!-- panel body with collapse capabale -->
                    <div class="table-responsive panel-collapse pull out">
                        <?php
                        foreach ($users_list as $user) {
                            $is_data = $user->random_id;
                        }
                        if (!isset($is_data) || empty($is_data)) {
                            echo "<h1 style='text-align:center;'>History not available for this " . DRIVER . "...</h1>";
                        } else {
                            ?>
                            <table class="table table-bordered table-hover" id="table1">
                                <thead>
                                    <tr>
                                        <!--<th width="3%" class="text-center"><i class="ico-long-arrow-down"></i></th>-->

                                        <th>Request Id</th>
                                        <th ><?php echo CLIENT; ?> Name</th>
                                        <th ><?php echo DRIVER; ?> Name</th>
                                        <th >Pickup Time</th>
                                        <th width="105">Detail History</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $base = base_url();

                                    function mili_to_time($milis) {
                                        $hours = (int) (($milis / (1000 * 60 * 60)) % 24);
                                        $minutes = (int) (($milis / (1000 * 60)) % 60);
                                        $seconds = (int) ($milis / 1000) % 60;
                                        $time = $hours . ":" . $minutes . ":" . $seconds;
                                        return $time;
                                    }

                                    foreach ($users_list as $user) {
                                        /* $devicetype = $user->device_type;
                                          if ($devicetype == 1) {
                                          $devicetype = "iPhone";
                                          } else {
                                          $devicetype = "Android";
                                          }
                                          $status = $user->confirm_status;
                                          if ($status == 1) {
                                          $status = "<span style='color:#005E20;'>Approve</span>";
                                          $statusadmin = "decline";
                                          } else {
                                          $status = "<span style='color:#FF0000;'>Pending</span>";
                                          $statusadmin = "Approve";
                                          }
                                          $trip_stat = $user->is_on_root;
                                          if ($trip_stat == '1') {
                                          $driver_trip_stat = "On Trip";
                                          } else {
                                          $driver_trip_stat = "Free";
                                          }
                                          $avail_stat = $user->is_busy;
                                          if ($avail_stat == '1') {
                                          $is_driver_stat = "<span style='color:#FF0000;'>Not available</span>";
                                          } else {
                                          $is_driver_stat = "<span style='color:#005E20;'>Available</span>";
                                          } */
                                        /* $mil = $user->time_of_pickup;
                                          $seconds = $mil / 1000;
                                          $mil = date("H:i:s", $seconds); */
                                        $mil = mili_to_time($user->time_of_pickup);
                                        echo "<tr>"
                                        . "<td>" . $user->random_id . "</td>"
                                        . "<td>" . $user->client_name . "</td>"
                                        . "<td>" . $user->driver_name . "</td>"
                                        . "<td>" . $mil . "</td>"
                                        . "<input type='hidden' name='eid' value='" . $user->driver_id . "'>"
                                        . "<td><button type='button' class='btn btn-green' onclick=\"location.href='" . $base . "index.php/users/detail_history?id=" . $user->random_id . "'\">Detail History</button></td>"
                                        . "</form>"
                                        . "</tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        <?php } ?>
                    </div>
                    <!--/ panel body with collapse capabale -->
                </div>
            </div>
        </div>
        <!--/ END row -->


    </div>
    <!--/ END Template Container -->

    <!-- START To Top Scroller -->
    <a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
    <!--/ END To Top Scroller -->
</section>

<script type="text/javascript">
    $('#all_drivers').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
</script>

<!--/ END Template Main -->

