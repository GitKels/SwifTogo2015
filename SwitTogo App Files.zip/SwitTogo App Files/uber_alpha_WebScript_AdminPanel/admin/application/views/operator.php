<?php
session_start();
$this->load->view('sidebar');
?>
<!-- Digit validation script -->

<script type="text/javascript">
    var specialKeys = new Array();
    specialKeys.push(8); //Backspace
    function IsNumeric(e) {
        var keyCode = e.which ? e.which : e.keyCode
        var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
        document.getElementById("error").style.display = ret ? "none" : "inline";
        return ret;
    }
</script>
<!-- START Template Main -->
<section id="main" role="main">
    <div class="container">
        <div class="row tab-content-caption">
            <div class="container">
                <div class="col-md-4 big-text">
                    <p>Change Operator</p>
                </div>
            </div>
        </div>
        <div class="row editable-content-div">
            <?php echo form_open('settings/updateoperator'); ?>
            <?php
            if (isset($_SESSION['not_change'])) {
                echo $_SESSION['not_change'];
                $_SESSION['not_change'] = "";
            }
            ?>
        </div>
    </div>
    <div class="container">
        <div class="col-md-4 notification-detail">
            <p>Change Operator Number</p>
            <i class="icon-phone"></i>

            <input name="operator" type="text" class="form-control" placeholder="Operator Number" onkeypress="return IsNumeric(event);" ondrop="return false;" onpaste="return false;" data-parsley-errors-container="#error-container" data-parsley-error-message="Please fill in your username / email" data-parsley-required required> 
             <i class="icon-phone"></i><!-- <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>-->
            <input name="operator_copy" type="text" class="form-control" placeholder="New Number" onkeypress="return IsNumeric(event);" ondrop="return false;" onpaste="return false;" data-parsley-errors-container="#error-container" data-parsley-error-message="Please fill in your password" data-parsley-required required>
            <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
            <div class="form-group nm">
                <button type="submit" class="btn btn-green" >Change</button>
            </div>
        </div>
    </div>
</form>
</div>
<!-- old code -->
<!-- START Template Container -->

<!-- Page Header -->

<!--/ END Template Container -->

<!-- START To Top Scroller -->
<div class="container">
    <a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
    <!--/ END To Top Scroller -->
</div>
</section>
<!--/ END Template Main -->

<!-- START Template Sidebar (right) -->

<!--/ END Template Sidebar (right) -->

<script type="text/javascript">
    $('#change_oper').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
</script>