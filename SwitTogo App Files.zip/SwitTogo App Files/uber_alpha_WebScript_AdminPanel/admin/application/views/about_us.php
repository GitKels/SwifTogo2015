<?php $this->load->view('sidebar'); ?>
<div class="row third-portion">
    <div class="tab-content">
        <div class="tab-pane fade" id="option3">
            <div class="row tab-content-caption">
                <div class="container">
                    <div class="col-md-4 big-text">
                        <p>Edit About Us</p>
                    </div>
                </div>
            </div>
            <?php echo form_open('settings/update_about'); ?>
            <?php
            if (isset($_SESSION['not_change'])) {
                echo $_SESSION['not_change'];
                $_SESSION['not_change'] = "";
            }
            foreach ($users_list as $user) {
                $id = $user->id;
                $about = br2nl($user->about);
                $link_1 = $user->link_1;
                $link_2 = $user->link_2;
            }
            $base = base_url();
            $base = str_replace('admin/', '', $base);

            function br2nl($text) {
                return preg_replace('/<br\\s*?\/??>/i', '', $text);
            }
            ?>
            <div class="row editable-content-div">
                <div class="container">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-6">
                                <label><i class="icon-male"></i> Id</label>
                                <input name="username" type="text" class="form-control" placeholder="Id" data-parsley-errors-container="#error-container" data-parsley-error-message="Please fill in your id" data-parsley-required required disabled value="<?php echo $id; ?>"><input name="ids" type="hidden" value="<?php echo $id; ?>"><br/>
                                <label for="data"><i class="icon-file"></i> Description</label>
                                <textarea name="data" id="data" rows="10" class="form-control" style="resize:vertical;" placeholder="Discription" data-parsley-errors-container="#error-container" data-parsley-error-message="Please fill in Discription" data-parsley-required required><?php echo $about; ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label for="link_1"><i class="icon-lock"></i>Privacy Policy Link</label>
                                <input name="link_1" id="link_1" type="text" class="form-control" value="<?php echo $link_1; ?>" placeholder="Privacy Policy Link" data-parsley-errors-container="#error-container" data-parsley-error-message="Please fill in Privacy Policy Link" data-parsley-required required><br/>
                                <label for="link_2"><i class="icon-phone"></i>Contact Us Link</label>
                                <input name="link_2" id="link_2"type="text" class="form-control" value="<?php echo $link_2; ?>" placeholder="Contact Us Link" data-parsley-errors-container="#error-container" data-parsley-error-message="Please fill in Contact Us Link" data-parsley-required required >
                                <br>
                                <button type="submit" class="btn btn-green"> Update</button>
                            </div>
                        </div>
                        <br/>
                        <!--<p>View updated page : <a href="<?php echo $base . "ws/about_us.php" ?>" target="_blank">Click me</a></p>-->
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#change_about').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
</script>
