<html>
    <!-- START Head -->
    <head>
        <!-- START META SECTION -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo PAGE_TITLE; ?> - Web Dashboard</title>
        <meta name="author" content="pampersdry.info">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">

        <!-- Library script : mandatory -->

        <script>
            var base_url = "<?php echo base_url() ?>";

        </script>

        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/jquery/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/jquery/js/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/core/js/core.min.js"></script>
        <!--/ Library script -->


        <link rel="icon" type="image/png" href="<?php echo base_url(); ?>/public/image/favicon.png">
        <link rel="icon" type="image/ico" href="<?php echo base_url(); ?>/public/image/favicon.ico">

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="image/touch/apple-touch-icon-144x144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="image/touch/apple-touch-icon-114x114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="image/touch/apple-touch-icon-72x72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="image/touch/apple-touch-icon-57x57-precomposed.png">
        <link rel="shortcut icon" href="image/touch/apple-touch-icon.png">


        <!--/ END META SECTION -->

        <!-- START STYLESHEETS -->
        <!-- Plugins stylesheet : optional -->

        <!--/ Plugins stylesheet -->
        <!-- added code for new theme -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/responsive-style.css">

        <!-- Application stylesheet : mandatory -->
        <!--<link rel="stylesheet" href="<?php echo base_url(); ?>/public/library/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/layout.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/uielement.min.css">

        <link rel="stylesheet"href="<?php echo base_url(); ?>/public/plugins/datatables/css/jquery.datatables.min.css">
        -->
        <!--/ Application stylesheet -->
        <!-- END STYLESHEETS -->

        <!-- START JAVASCRIPT SECTION - Load only modernizr script here -->
        <script src="<?php echo base_url(); ?>/public/library/modernizr/js/modernizr.min.js"></script>
        <script src="http://code.google.com/apis/maps/documentation/javascript/services.html#Geocoding"></script>

        <!--/ END JAVASCRIPT SECTION -->
    </head>
    <!--/ END Head -->

    <!-- START Body -->
    <body>

        <div class="container">
            <div class="row towber-nav">
                <div class="col-md-5 logo">
                    <h3><img src="<?php echo base_url(); ?>/public/stylesheet/img/logo-text.png" > <?php echo APP_TITLE; ?></h3>
                </div>


                <div class="col-md-2 nav-select">
                    <div class="dropdown">

                        <!-- testing -->
                        <?php
                        $attributes = array('method' => 'GET', 'id' => 'myform');
                        echo form_open('users/search', $attributes);
                        ?>
                        <div class="has-icon">

                            <select class="form-control" name ="type">
                                <option value="Driver"><?php echo DRIVER; ?></option>
                                <option value="Client"><?php echo CLIENT; ?></option>
                            </select>
                        </div>
                    </div></div>
                <div class="col-md-2 nav-search"><input type="text" name="q" class="form-control" placeholder="Search"> 
                    <i type='submit' class="icon-search"></i></div>

                </form>

                <!-- end testing -->





                <div class="col-md-2 nav-admin">
                    <div class="dropdown">
                        <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
                            <i class="icon-smile"></i> Hello Admin
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                            <li role="presentation"> <?php echo anchor('login/logout', '<span class="icon"><i class="ico-exit"></i></span>
                            <span class="text">Logout</span>'); ?></li>
                        </ul>
                    </div>
                </div>
                <!--<div class="col-md-2 nav-search">
                  <input type="text" class="form-control" placeholder="Search"><i class="icon-search"></i>
                </div>-->
                </form>
            </div>
        </div> 

        <!-- old code -->