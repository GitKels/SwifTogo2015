


<!--/ END Template Header -->

<!-- START Template Sidebar (Left) -->
<?php echo $this->load->view('sidebar'); ?>
<!--/ END Template Sidebar (Left) -->

<!-- START Template Main -->
<section id="main" role="main">
    
    
        <div class="row tab-content-caption">
          <div class="container">
            <div class="col-md-4 big-text">
              <p>REQUESTS ON MAP</p>
            </div>
            <div class="col-md-6 notification-detail">
              <p>All <?php echo CLIENT; ?> Requests</p>
            </div>
          </div>
        </div>
      

      <!-- old code -->
    <!-- START Template Container <div class="container-fluid"> -->
    <div class="container">
        <!-- Page Header -->
       <!-- <div class="page-header page-header-block">
            <div class="page-header-section">
                <h4 class="title semibold">Requests on MAP</h4>
            </div>
        </div> -->
        <!-- Page Header -->
        <!-- START row -->
        <div class="row">
            <div class="col-md-12">
                <!-- START panel <div class="panel panel-primary">-->
                <div>
                    <br> <!-- panel heading/header <div class="panel-heading"> -->
                    <div>
                        <br>                      
 <!-- <h3 class="panel-title"><span class="panel-icon mr5"><i class="ico-table22"></i></span>All <?php echo CLIENT; ?> requests</h3> -->
                        <!-- panel toolbar -->
                        <!--<div class="panel-toolbar text-right">
                            <div class="option">
                                <button class="btn up" data-toggle="panelcollapse"><i class="arrow"></i></button>
                                <button class="btn" data-toggle="panelremove" data-parent=".col-md-12"><i class="remove"></i></button>
                            </div>
                        </div>-->
                        <!--/ panel toolbar -->
                    </div>
                    <!--/ panel heading/header -->
                    <!-- panel toolbar wrapper -->
                    <?php echo form_open('data_controller/delete_driver'); ?>
                    <div class="panel-toolbar-wrapper pl0 pt5 pb5">
                        <!--<div class="panel-toolbar pl10">
                            <div class="checkbox custom-checkbox pull-left">  
                                <input type="checkbox" id="customcheckbox" value="1" data-toggle="checkall" data-target="#table1">  
                                <label for="customcheckbox">&nbsp;&nbsp;Select all</label>  
                                <a href="driver_aprove"><button type='button' class='btn btn-sm btn-info'>Aprove</button></a>
                                <a href="driver_pendding"><button type='button' class='btn btn-sm btn-info'>Pendding</button></a>
                            </div>
                        </div>
                        <div class="panel-toolbar text-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-default"><i class="ico-upload22"></i></button>
                                <button type="button" class="btn btn-sm btn-default"><i class="ico-archive2"></i></button>
                            </div>

                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are Your Sure Dlete It ?')"><i class="ico-remove3"></i></button>
                        </div>-->
                    </div>
                    <!--/ panel toolbar wrapper -->


                    <!-- panel body with collapse capabale -->
                    <div class="table-responsive panel-collapse pull out">
                        <div id="map" style="width: 100%; height: 500px"></div>
                    </div>
                    <!--/ panel body with collapse capabale -->
                </div>
            </div>
        </div>
        <!--/ END row -->


    </div>
    <!--/ END Template Container -->

    <!-- START To Top Scroller -->
    <a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
    <!--/ END To Top Scroller -->
</section>
<script type="text/javascript">
    $('#cli_requ').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
</script>


<!--/ END Template Main -->

