<!--/ END Template Header -->

<!-- START Template Sidebar (Left) -->
<?php echo $this->load->view('sidebar'); ?>
<!--/ END Template Sidebar (Left) -->


<!-- START Template Main -->
<section id="main" role="main">
    <!-- START Template Container <div class="container-fluid"> -->
    <div class="container">
        <!-- Page Header -->
        <!-- <div class="page-header page-header-block">
             <div class="page-header-section">
                 <h4 class="title semibold"><?php echo DRIVER; ?>s List</h4>
             </div>
         </div> -->
        <!-- Page Header -->

        <div class="row tab-content-caption">
            <div class="container">
                <div class="col-md-4 big-text">
                    <p><?php echo DRIVER; ?>s List</p>
                </div>
                <div class="col-md-6 notification-detail">
                    <p>All the <?php echo DRIVER; ?>s</p>
                </div>
            </div>
        </div>

        <!-- START row -->
        <!--  <div class="row">
              <div class="col-md-12"> -->
        <!-- START panel -->
        <!-- <div class="panel panel-primary">-->
        <!-- panel heading/header -->
        <!-- <div class="panel-heading">
            <h3 class="panel-title"><span class="panel-icon mr5"><i class="ico-table22"></i></span>All the users</h3>
        --><!-- panel toolbar -->
        <!-- <div class="panel-toolbar text-right"> -->
        <!-- option -->
        <!--<div class="option">
            <button class="btn up" data-toggle="panelcollapse"><i class="arrow"></i></button>
            <button class="btn" data-toggle="panelremove" data-parent=".col-md-12"><i class="remove"></i></button>
        </div> -->
        <!--/ option -->
        <!--   </div> -->
        <!--/ panel toolbar -->
        <!--   </div> -->
        <!--/ panel heading/header -->
        <!-- panel toolbar wrapper -->
        <?php echo form_open('data_controller/delete_driver'); ?>


        <div class="row editable-options">
            <div class="container">
                <div class="col-md-2">
                    <input type="checkbox" id="customcheckbox" value="1" data-toggle="checkall" data-target="#table1">  
                    <label for="customcheckbox">&nbsp;&nbsp;Select all</label>
                </div>
                <div class="col-md-1">
                    <!--<a href="driver_aprove"><button type='button' class='btn btn-green'>Approved</button></a> -->
                    <button type="button" class="btn btn-green" onclick="location.href = 'driver_aprove'">&nbsp;Approved&nbsp;</button>
                </div>
                <div class="col-md-1">
                    <a href="driver_pendding"><button type='button' class='btn btn-green'>&nbsp;Pending&nbsp;</button></a>
                </div>
                <div class="col-md-5">

                </div>
                <div class="col-md-3 options-right-icon">
                    <i class="icon-upload"></i><i class="icon-archive"></i>
                    <span onclick="return confirm('Are Your Sure Dlete It ?')"><i class="icon-trash"></i></span>
                </div>
            </div>
        </div>

        <div class="table-responsive panel-collapse pull out">
            <table class="table table-bordered table-hover" id="table1" style="margin-left: -80px;">
                <thead>
                    <tr>
                        <td width="3%" class="text-center"><i class="icon-arrow-down"></i></td>

                        <td id="driver_arrange">Name <i class=""></i></td>
                        <td>Email</td>
                        <td >Phone</td>
                        <td >Gender</td>
                        <td >Rating</td>
                        <td ><?php echo DRIVER_WORK; ?></td>
                        <td ><?php echo DRIVER; ?> Status</td>
                        <td width="70">Device</td>
                        <td >Confirm Status</td>
                        <td width="100">Availability</td>
                        <td width="50">History</td>
                        <td colspan="2"></td>
                    </tr>
                </thead>
                <tbody id="driver_data">
                    <?php
                    $base = base_url();
                    foreach ($users_list as $user) {
                        $devicetype = $user->device_type;
                        if ($devicetype == 1) {
                            $devicetype = "iPhone";
                        } else {
                            $devicetype = "Android";
                        }
                        $status = $user->confirm_status;
                        if ($status == 1) {
                            $status = "<span style='color:#005E20;'>Approved</span>";
                            $statusadmin = "Decline";
                        } else {
                            $status = "<span style='color:#FF0000;'>Pending</span>";
                            $statusadmin = "Approved";
                        }
                        $trip_stat = $user->is_on_root;
                        if ($trip_stat == '1') {
                            $driver_trip_stat = "On Trip";
                        } else {
                            $driver_trip_stat = "Free";
                        }
                        $avail_stat = $user->is_busy;
                        if ($avail_stat == '1') {
                            $is_driver_stat = "<span style='color:#FF0000;'>Not available</span>";
                        } else {
                            $is_driver_stat = "<span style='color:#005E20;'>Available</span>";
                        }


                        echo "<tr>"
                        . "<td>"
                        . "<input type='checkbox' id='customcheckbox1[]' name='customcheckbox1[]' value=' $user->driver_id  ' data-toggle='selectrow' data-target='tr' data-contextual='success'>"
                        . "<label for='customcheckbox1'></label>"
                        . "</td>"
                        . "<td>" . $user->name . "</td>"
                        . "<td>" . $user->email . "</td>"
                        . "<td>" . $user->country_code . $user->contact . "</td>"
                        . "<td>" . $user->gender . "</td>"
                        . "<td>" . $user->rating . "</td>"
                        . "<td>" . $user->total_trips . "</td>"
                        . "<td>" . $driver_trip_stat . "</td>"
                        . "<td>" . $devicetype . "</td>"
                        . "<td>" . $status . "</td>"
                        . "<td>" . $is_driver_stat . "</td>"
                        . "<input type='hidden' name='eid' value='" . $user->driver_id . "'>"
                        . "<td><button type='button' class='btn btn-green' onclick=\"location.href='" . $base . "index.php/users/driver_history?id=" . $user->driver_id . "'\">History</button></td>"
                        . "<td class='text-center' style='border-right:0px;'>"
                        . "<!-- button toolbar -->"
                        . "<div class='toolbar'>"
                        . "<div class='btn-group'>"
                        . "<button type='submit' value='" . $user->driver_id . "' name='did' class='btn btn-nothing' onclick=\"return confirm('Are Your Sure Dlete It ?')\">Delete</button>"
                        . "</div>"
                        . "</div>"
                        . "<!--/ button toolbar -->"
                        . "</td>"
                        . "<td class='text-center' style='border-left:0px'>"
                        . "<!-- button toolbar -->"
                        . "<div class='toolbar'>"
                        . "<div class='btn-group'>"
                        . "<button type='submit' value='" . $user->driver_id . "' name='aprove'id='aprove' class='btn btn-green'>$statusadmin</button>"
                        . "</div>"
                        . "</div>"
                        . "<!--/ button toolbar -->"
                        . "</td>"
                        . "</form>"
                        . "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <!--/ panel body with collapse capabale -->
    </div>
</div>
</div>
<!--/ END row -->


</div>
<!--/ END Template Container -->

<!-- START To Top Scroller -->
<a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
<!--/ END To Top Scroller -->
</section>
<script type="text/javascript">
    $('#all_drivers').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
    
    var num = 1;
    $('#driver_arrange').css('cursor', 'pointer');
    $('#driver_arrange').click(function() {
        if (num % 2 == 0) {
            $('#driver_arrange > i').removeClass('icon-arrow-up');
            $('#driver_arrange > i').addClass('icon-arrow-down');
            $('#driver_data').load('<?php echo base_url(); ?>index.php/users/driver_arrange?arrange=DESC').fadeIn("slow");
        } else {
            $('#driver_arrange > i').removeClass('icon-arrow-down');
            $('#driver_arrange > i').addClass('icon-arrow-up');
            $('#driver_data').load('<?php echo base_url(); ?>index.php/users/driver_arrange?arrange=ASC').fadeIn("slow");
        }
        num++;
    });
</script>



<!--/ END Template Main -->

