        <!-- START JAVASCRIPT SECTION (Load javascripts at bottom to reduce load time) -->
        <!-- Library script : mandatory -->

        <!--/ Library script -->

        <!-- App and page level script -->
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/sparkline/js/jquery.sparkline.min.js"></script><!-- will be use globaly as a summary on sidebar menu -->
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/javascript/app.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/flot/jquery.flot.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/flot/jquery.flot.categories.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/flot/jquery.flot.tooltip.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/flot/jquery.flot.resize.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/flot/jquery.flot.spline.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/javascript/pages/dashboard.js"></script>
        
             <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/datatables/js/jquery.datatables.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/datatables/tabletools/js/tabletools.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/datatables/tabletools/js/zeroclipboard.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/datatables/js/jquery.datatables-custom.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/javascript/tables/datatable.js"></script>
              <script type="text/javascript" src="<?php echo base_url(); ?>/public/plugins/parsley/js/parsley.min.js"></script>
        
        <script type="text/javascript" src="javascript/pages/login.js"></script>
        <!--/ App and page level scrip -->
        <!--/ END JAVASCRIPT SECTION -->
    </body>
    <!--/ END Body -->
</html>