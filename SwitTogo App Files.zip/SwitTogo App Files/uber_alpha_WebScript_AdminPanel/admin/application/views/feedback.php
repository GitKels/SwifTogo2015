

<!--/ END Template Header -->

<!-- START Template Sidebar (Left) -->
<?php echo $this->load->view('sidebar'); ?>
<!--/ END Template Sidebar (Left) -->

<!-- START Template Main -->
<section id="main" role="main">
    
        <div class="row tab-content-caption">
          <div class="container">
            <div class="col-md-4 big-text">
              <p><?php echo CLIENT; ?>s Feedbacks</p>
            </div>
            <div class="col-md-6 notification-detail">
              <p></p>
            </div>
          </div>
        </div>
        <!--<div class="row editable-options">
        <div class="container">
          <div class="col-md-2">
            <input type="checkbox"> &nbsp;Select All
          </div>
          <div class="col-md-7">
            
          </div>
          <div class="col-md-3 options-right-icon">
            <i class="icon-upload"></i><i class="icon-archive"></i><i class="icon-trash"></i>
          </div>
        </div>
        </div>-->
      

    <!-- old code -->
    <!-- START Template Container <div class="container-fluid"> -->
    
    <div class="container">
        <!-- Page Header -->
        <!--<div class="page-header page-header-block">
            <div class="page-header-section">
                <h4 class="title semibold"><?php echo CLIENT; ?> Feedbacks</h4>
            </div>
        </div> -->
        <!-- Page Header -->

        <!-- START row -->
        <!--<div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary"> -->
                <!-- START panel -->
                
                    <!-- panel heading/header -->
                   <!-- <div class="panel-heading">
                        <h3 class="panel-title"><span class="panel-icon mr5"><i class="ico-table22"></i></span>All the users</h3> -->
                        <!-- panel toolbar -->
                        <!-- <div class="panel-toolbar text-right"> -->
                            <!-- option -->
                           <!-- <div class="option">
                                <button class="btn up" data-toggle="panelcollapse"><i class="arrow"></i></button>
                                <button class="btn" data-toggle="panelremove" data-parent=".col-md-12"><i class="remove"></i></button>
                            </div> -->
                            <!--/ option -->
                       <!-- </div> -->
                        <!--/ panel toolbar -->
                   <!-- </div> -->
                    <!--/ panel heading/header -->
                    <!-- panel toolbar wrapper -->
                    <?php echo form_open('data_controller/delete_user'); ?>
                    <div class="panel-toolbar-wrapper pl0 pt5 pb5">
                        
                    </div>
                    <!--/ panel toolbar wrapper -->


                    <!-- panel body with collapse capabale -->
                    <div class="table-responsive panel-collapse pull out">
                        <table class="table table-bordered table-hover" id="table1">
                            <thead>
                                <tr>
                                    <td width="3%" class="text-center">Id</td>

                                    <td><?php echo DRIVER; ?> Name</td>
                                    <td><?php echo CLIENT; ?> Name</td>
                                    <td width="50">Rating</td>

                                    <td width="150">Time</td>
                                    <td width="550">Comment</td>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($users_list as $user) {


                                    echo "<tr>
                                            <td> $user->feedback_id 
                                                     
                                            </td>" .
                                    "
                                            <td>" . $user->drivername . "</td>
                                            <td>" . $user->clientname . "</td>
                                            
                                            <td>" . $user->rating . "</td>
                                             <td>" . $user->time . "</td>
                                             <td>" . $user->comment . "</td>
                                                <input type='hidden' name='eid' value='" . $user->time . "'>
                                            
                                            </form>
                                        </tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <!--/ panel body with collapse capabale -->
                </div>
            </div>
        </div>
        <!--/ END row -->


    </div>
    <!--/ END Template Container -->

    <!-- START To Top Scroller -->
    <a href="#" class="totop animation" data-toggle="waypoints totop" data-marker="#main" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="-50%"><i class="ico-angle-up"></i></a>
    <!--/ END To Top Scroller -->
</section>
<!--/ END Template Main -->

<script type="text/javascript">
    $('#all_feedbacks').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
</script>
