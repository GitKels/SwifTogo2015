<html>
    <!-- START Head -->
    <head>
        <!-- START META SECTION -->
        <meta charset="utf-8">
        <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
        <title><?php echo PAGE_TITLE; ?> - Web Dashboard</title>
        <meta name="author" content="pampersdry.info">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
        <!-- Library script : mandatory -->
        <script>
            var base_url = "<?php echo base_url() ?>";

        </script>

        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/jquery/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/jquery/js/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/public/library/core/js/core.min.js"></script> 
        <!-- /Library script : mandatory -->
        <link rel="icon" type="image/png" href="<?php echo base_url(); ?>/public/image/favicon.png">
        <link rel="icon" type="image/ico" href="<?php echo base_url(); ?>/public/image/favicon.ico">

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="image/touch/apple-touch-icon-144x144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="image/touch/apple-touch-icon-114x114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="image/touch/apple-touch-icon-72x72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="image/touch/apple-touch-icon-57x57-precomposed.png">
        <link rel="shortcut icon" href="image/touch/apple-touch-icon.png">
        <!--/ END META SECTION -->

        <!-- START STYLESHEETS -->
        <!-- Plugins stylesheet : optional -->

        <!--/ Plugins stylesheet -->

        <!-- added code for new theme -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/css/responsive-style.css">

        <!-- Application stylesheet : mandatory -->
        <!--<link rel="stylesheet" href="<?php echo base_url(); ?>/public/library/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/layout.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/public/stylesheet/uielement.min.css">

        <link rel="stylesheet"href="<?php echo base_url(); ?>/public/plugins/datatables/css/jquery.datatables.min.css">
        --> <!--/ Application stylesheet -->
        <!-- END STYLESHEETS -->

        <!-- START JAVASCRIPT SECTION - Load only modernizr script here -->
        <script src="<?php echo base_url(); ?>/public/library/modernizr/js/modernizr.min.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"
        type="text/javascript"></script>
        <script type="text/javascript">
            //<![CDATA[
            var markersArray = [];
            var newmarkersArray = [];
            var customIcons = {
                restaurant: {
                    icon: 'http://labs.google.com/ridefinder/images/mm_20_blue.png',
                    shadow: 'http://labs.google.com/ridefinder/images/mm_20_shadow.png'
                },
                bar: {
                    icon: 'http://labs.google.com/ridefinder/images/mm_20_red.png',
                    shadow: 'http://labs.google.com/ridefinder/images/mm_20_shadow.png'
                },
                client: {
                    icon: '<?php echo base_url(); ?>/public/image/client-70.png',
                    shadow: 'http://labs.google.com/ridefinder/images/mm_20_shadow.png'
                },
                driver: {
                    icon: '<?php echo base_url(); ?>/public/image/driver-70.png',
                    shadow: 'http://labs.google.com/ridefinder/images/mm_20_shadow.png'
                }
            };

            function load() {

                var map = new google.maps.Map(document.getElementById("map"), {
                    center: new google.maps.LatLng(22.2725205, 70.7490713),
                    zoom: 4,
                    mapTypeId: 'roadmap'
                });
                var infoWindow = new google.maps.InfoWindow;

                // Change this depending on the name of your PHP file
                (function() {
                    var f = function() {
                        var marker = new google.maps.Marker();
                        downloadUrl("<?php echo base_url(); ?>index.php/users/driver_pin_ajax", function(data) {
                            var xml = data.responseXML;
                            var markers = xml.documentElement.getElementsByTagName("marker");
                            for (var i = 0; i < markers.length; i++) {
                                var name = markers[i].getAttribute("name");
                                var address = markers[i].getAttribute("address");
                                var client_name = markers[i].getAttribute("client_name");
                                var contact = markers[i].getAttribute("contact");
                                var email = markers[i].getAttribute("email");
                                var type = markers[i].getAttribute("type");
                                var point = new google.maps.LatLng(
                                        parseFloat(markers[i].getAttribute("lat")),
                                        parseFloat(markers[i].getAttribute("lng")));
                                var html = "";
                                if (type == "driver") {
                                    html = "<b>" + name + "</b> <br/> <p><span class='icon-phone' style=''></span><span style='margin-left:5px;'>" + contact + "</span><br/></p><p>Rating : " + email + "</p><p><a href='<?php echo base_url(); ?>index.php/users/assign_driver?driver_id=" + address + "'>Assign</a></p>";
                                } else {
                                    html = "<p><b>" + client_name + "</b></p><p><span class='icon-phone' style=''></span><span style='margin-left:5px;'>" + contact + "</span</p><br><b>" + name + "</b> <br/>";
                                }
                                var icon = customIcons[type] || {};
                                marker = new google.maps.Marker({
                                    map: map,
                                    position: point,
                                    icon: icon.icon,
                                    shadow: icon.shadow
                                });
                                newmarkersArray.push(marker);
                                bindInfoWindow(marker, map, infoWindow, html);
                            }
                            clearOverlays(markersArray);
                            markersArray = newmarkersArray;
                            newmarkersArray = [];
                        });
                    };
                    window.setInterval(f, 15000);
                    f();
                    
                    var legendDiv = document.createElement('DIV');
                    var legend = new Legend(legendDiv, map);
                    legendDiv.index = 1;
                    map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legendDiv);
                    
                })();
            }
            function clearOverlays(arr) {
                for (var i = 0; i < arr.length; i++) {
                    arr[i].setMap(null);
                }
            }
            function bindInfoWindow(marker, map, infoWindow, html) {
                google.maps.event.addListener(marker, 'click', function() {
                    infoWindow.setContent(html);
                    infoWindow.open(map, marker);
                });
            }

            function downloadUrl(url, callback) {
                var request = window.ActiveXObject ?
                        new ActiveXObject('Microsoft.XMLHTTP') :
                        new XMLHttpRequest;

                request.onreadystatechange = function() {
                    if (request.readyState == 4) {
                        request.onreadystatechange = doNothing;
                        callback(request, request.status);
                    }
                };

                request.open('GET', url, true);
                request.send(null);
            }
            function doNothing() {
            }
            function Legend(controlDiv, map) {
                // Set CSS styles for the DIV containing the control
                // Setting padding to 5 px will offset the control
                // from the edge of the map
                controlDiv.style.padding = '5px';

                // Set CSS for the control border
                var controlUI = document.createElement('DIV');
                controlUI.style.backgroundColor = 'white';
                controlUI.style.borderStyle = 'solid';
                controlUI.style.borderWidth = '1px';
                controlUI.title = 'Legend';
                controlDiv.appendChild(controlUI);

                // Set CSS for the control text
                var controlText = document.createElement('DIV');
                controlText.style.fontFamily = 'Arial,sans-serif';
                controlText.style.fontSize = '12px';
                controlText.style.paddingLeft = '4px';
                controlText.style.paddingRight = '4px';

                // Add the text
                controlText.innerHTML = '<b>Legends</b><br />' +
                        '<img src="<?php echo base_url(); ?>/public/image/client-70.png" style="height:25px;"/> <?php echo CLIENT; ?><br />' +
                        '<img src="<?php echo base_url(); ?>/public/image/driver-70.png" style="height:25px;"/> <?php echo DRIVER; ?><br />' +
                        '<small>*Data is fictional</small>';
                controlUI.appendChild(controlText);
            }

            //]]>
        </script>
        <!--/ END JAVASCRIPT SECTION -->
    </head>
    <!--/ END Head -->

    <!-- START Body -->
    <body onload="load()">

        <div class="container">
            <div class="row towber-nav">
                <div class="col-md-5 logo">
                    <h3><img src="<?php echo base_url(); ?>/public/stylesheet/img/logo-text.png" ><?php echo APP_TITLE; ?></h3>
                </div>



                <div class="col-md-2 nav-select">
                    <div class="dropdown">
                        <?php
                        $attributes = array('method' => 'GET', 'id' => 'myform');
                        echo form_open('users/search', $attributes);
                        ?>
                        <div class="has-icon">

                            <select class="form-control" name ="type">
                                <option value="Driver"><?php echo DRIVER; ?></option>
                                <option value="Client"><?php echo CLIENT; ?></option>
                            </select>
                        </div>
                    </div></div>
                <div class="col-md-2 nav-search"><input type="text" name="q" class="form-control" placeholder="Search"> 
                    <i type='submit' class="icon-search"></i></div>

                </form>

                <div class="col-md-2 nav-admin">
                    <div class="dropdown">
                        <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
                            <i class="icon-smile"></i> Hello Admin
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                            <li role="presentation"> <?php echo anchor('login/logout', '<span class="icon"><i class="ico-exit"></i></span>
                            <span class="text">Logout</span>'); ?></li>
                        </ul>
                    </div>
                </div>
                <!--<div class="col-md-2 nav-search">
                  <input type="text" class="form-control" placeholder="Search"><i class="icon-search"></i>
                </div>-->
                </form>
            </div>
        </div>
        <!--<button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
        <?php echo DRIVER; ?>
        <span class="caret"></span>
      </button>
      <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
        <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Stranger</a></li>
      </ul> -->


        <!-- new code added-->


        <!-- Profile dropdown -->


        <!--<li class="dropdown profile">
            <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">
                <span class="meta">
                    
                    <span class="text hidden-xs hidden-sm pr5 pl5">Hello Admin</span>
                    <span class="arrow"></span>
                </span>
            </a>
            <ul class="dropdown-menu" role="menu">
                
                <li>  <?php echo anchor('login/logout', '<span class="icon"><i class="ico-exit"></i></span>
                            <span class="text">Logout</span>'); ?></li>

            </ul> -->


        <!--end of new code added-->
    </div>
</div> 
<!-- old code -->
<!-- START Template Header -->

<!--  <header id="header" class="navbar navbar-fixed-top"> -->
<!-- START navbar header -->

<!-- Brand -->
<!-- <div class="navbar-header">

<?php
$attributes = array('class' => 'navbar-brand');
echo anchor('welcome', '
                    <span class="logo-text"></span>', $attributes);
?>
</div> -->                
<!--/ Brand -->

<!--/ END navbar header -->

<!-- START Toolbar -->

<!-- START Left nav -->
<!-- <div class="navbar-toolbar clearfix">
<ul class="nav navbar-nav navbar-left">
    <div class="navbar-form navbar-left" >
<?php
$attributes = array('method' => 'GET', 'id' => 'myform');
echo form_open('users/search', $attributes);
?>
        <div class="has-icon">

            <select class="form-control" name ="type">
<option value="Driver"><?php echo DRIVER; ?></option>
<option value="Client"><?php echo CLIENT; ?></option>
</select><input type="text" name="q" class="form-control" placeholder="Search user..."> 
            <i type='submit' class="ico-search form-control-icon"></i>
        </div>
        </form>




    </div>


</ul>

<ul class="nav navbar-nav navbar-right">
--> <!-- Profile dropdown -->

<!-- <li class="dropdown profile">
    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">
        <span class="meta">
            <span class="avatar"><img src="<?php echo base_url(); ?>/public/image/avatar/avatar.png" class="img-circle" alt="" /></span>
            <span class="text hidden-xs hidden-sm pr5 pl5">Hello Admin</span>
            <span class="arrow"></span>
        </span>
    </a>
    <ul class="dropdown-menu" role="menu">
        <li>  <?php echo anchor('welcome', '<span class="icon"><i class="ico-home3"></i></span>
                            <span class="text">Dashboard</span>'); ?></li>

        <li>  <?php echo anchor('settings', '<span class="icon"><i class="ico-cog4"></i></span>
                            <span class="text">Settings</span>'); ?></li>
        <li>  <?php echo anchor('users', '<span class="icon"><i class="ico-user"></i></span>
                            <span class="text">List of users</span>'); ?></li>
        <li class="divider"></li>
        <li>  <?php echo anchor('login/logout', '<span class="icon"><i class="ico-exit"></i></span>
                            <span class="text">Logout</span>'); ?></li>

    </ul>
</li>

</ul>
</div>
</header> -->
<!--/ END Right nav -->


<!--/ END Toolbar -->
