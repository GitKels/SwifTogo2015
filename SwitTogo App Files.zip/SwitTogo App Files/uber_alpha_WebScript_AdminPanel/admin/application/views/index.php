<!--/ END Template Header -->

<!-- START Template Sidebar (Left) -->
<?php echo $this->load->view('sidebar'); ?>
<!--/ END Template Sidebar (Left) -->
<div class="row third-portion">
    <div class="tab-content">
        <div class="container">
            <div class="row towber-nav">
                <div class="row tab-content-caption">
                    <div class="container">
                        <div class="col-md-3 big-text">
                            <p>DASHBOARD</p>
                        </div>
                        <div class="col-md-6 notification-detail">
                            <p>Latest <?php echo CLIENT; ?> Request</p>
                        </div>
                        <div class="col-md-2 update-detail" >
                            <p onclick="location.reload();">

                                <i class="icon-refresh"></i> 
                                 <!-- <i class="icon-refresh"></i> --> UPDATE</p>
                        </div>
                    </div>
                </div>

                <div class="row content-div">
                    <div class="container">
                        <div class="col-md-6 welcome-text">
                            <p>Welcome to</p>
                            <p><?php echo APP_TITLE; ?></p>
                        </div>
                        <div class="col-md-6 requests">
                        <?php
                        $i = 0;
                        foreach ($users_list as $user) {
                            if (++$i == 5)
                                break;
                            $is_complete = $user->complete_status;
                            if ($is_complete == 0) {
                                echo"<div class='row'>"
                                . "" . anchor('users/go_to_map?id=' . urlencode($user->random_id), ""
                                        . "<div class='col-md-2 request-pic' style='text-align:center;'>"
                                        . "<img src='".  base_url()."/public/image/menu_buttons/user_requests.png' style='margin-top:6px; height:45px; width:45px;'/>"
                                        . "</div>") . ""
                                . "<div class='col-md-10 request-details'>"
                                . "<p>" . $user->name . " : <span class='right'>" . date('Y-m-d H:i:s', strtotime($user->request_time)) . "</span></p>"
                                . "<p>Request ID : " . $user->random_id . "</p>"
                                . "</div>"
                                . "</div>";
                            } else {
                                echo"<div class='row'>"
                                . "" . anchor('users/detail_history?id=' . urlencode($user->random_id), ""
                                        . "<div class='col-md-2 request-pic' style='text-align:center;'>"
                                        . "<img src='".  base_url()."/public/image/menu_buttons/user_requests.png' style='margin-top:6px; height:45px; width:45px;'/>"
                                        . "</div>") . ""
                                . "<div class='col-md-10 request-details'>"
                                . "<p>" . $user->name . " : <span class='right'>" . date('Y-m-d H:i:s', strtotime($user->request_time)) . "</span></p>"
                                . "<p>Request ID : " . $user->random_id . "</p>"
                                . "</div>"
                                . "</div>";
                            }
                        }
                        ?>
                        </div>
                    </div>
                </div>  
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#home').addClass('active');
    $('#option3').show();
    $('.fade').css('opacity', '1');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('color', '#ffffff');
    $('.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus').css('background-color', '#BD0E02');
</script>

<!--/ END Template Main -->

<!-- START Template Sidebar (right) -->

<!--/ END Template Sidebar (right) -->

