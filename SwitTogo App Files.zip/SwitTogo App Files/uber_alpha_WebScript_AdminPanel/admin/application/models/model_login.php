<?php

class model_login extends CI_Model{
    
    public function login($username,$password){
        
        $this->db->select('id');
        $this->db->from('admin');
        $this->db->where('username',$username);
        $this->db->where('pass',$password);
       $query= $this->db->get();
        if($query->num_rows()==1){
            return 1;
           
        }
        else{
            return 0;
        }
            
    }

    public function getadmininfo($id){
       $query= $this->db->query("SELECT * FROM admin where id='$id'");
       return $query;
    }
}