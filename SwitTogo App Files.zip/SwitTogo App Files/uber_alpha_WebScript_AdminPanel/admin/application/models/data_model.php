<?php

class data_model extends CI_Model {

    public function users_count() {
        $query = $this->db->query("select *  from driver_data where DATE(reg_time)=CURDATE()");
        $count = $query->num_rows();

        return $count;
    }

    public function users_count_date($date) {
        $query = $this->db->query("select * from client_request_data where date(request_time)='$date'");
        $count = $query->num_rows();
        return $count;
    }

    public function total_messages_date($date) {
        $query = $this->db->query("select * from client_data where date(reg_time)='$date'");
        $count = $query->num_rows();

        return $count;
    }

    public function total_groups_date($date) {
        $query = $this->db->query("select * from client_request_data where date(request_time)='$date'");
        $count = $query->num_rows();
        return $count;
    }

    public function total_groups() {
        $query = $this->db->query("select * from i_group WHERE DATE(time)=CURDATE()");
        $count = $query->num_rows();
        return $count;
    }

    public function chat_count() {
        $query = $this->db->query("select * from client_data WHERE DATE(reg_time)=CURDATE()");
        $count = $query->num_rows();
        return $count;
    }

    public function male_count_today() {
        $query = $this->db->query("select * from i_user where time=NOW()");
        $count = $query->num_rows();
        return $count;
    }

    public function female_count_today() {
        $query = $this->db->query("select * from i_user where time=NOW()");
        $count = $query->num_rows();

        return $count;
    }

    public function users_list() {
        $query = $this->db->query("SELECT client_data.name, client_request_data.random_id, client_request_data.request_id, client_request_data.request_time, client_request_data.complete_status FROM client_request_data LEFT JOIN client_data ON client_request_data.client_id=client_data.client_id ORDER BY client_request_data.request_id DESC");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function client_list() {
        $query = $this->db->query("SELECT * FROM client_data");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function new_request_list() {
        $query = $this->db->query("SELECT * FROM client_data");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function driver_list() {
        $query = $this->db->query("select * from driver_data");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function driver_aprove() {
        $query = $this->db->query("select * from driver_data where confirm_status='1'");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function driver_pendding() {
        $query = $this->db->query("select * from driver_data where confirm_status='0'");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function feedback_list() {


        //select fd.feedback_id,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as name,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from feedback_data fd
        $query = $this->db->query("select *,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as drivername,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from feedback_data fd");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function jobcompleted() {


        //select fd.feedback_id,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as name,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from feedback_data fd
        $query = $this->db->query("select *,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as drivername,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from client_request_data fd ORDER BY fd.complete_status");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function only_jobcompleted() {


        //select fd.feedback_id,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as name,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from feedback_data fd
        $query = $this->db->query("select *,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as drivername,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from client_request_data fd where complete_status='1'");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function not_jobcompleted() {


        //select fd.feedback_id,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as name,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from feedback_data fd
        $query = $this->db->query("select *,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as drivername,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from client_request_data fd where complete_status='0'");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function client_ajax() {


        //select fd.feedback_id,(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as name,(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname from feedback_data fd
        $query = $this->db->query("SELECT * FROM client_request_data WHERE driver_id='0' AND request_status='0' AND cancel_flg='0'");
        //$data = mysql_fetch_assoc($query);
        //echo $query;
        //return $data;
        return $query->result();
    }

    public function users_list_search($string) {
        $query = $this->db->query("select * from client_data where name  like '%$string%'  or email  like '%$string%'");

        //$query = $this->db->query("select * from client_data where name  like '%$string%'  or email  like '%$string%'");


        return $query->result();
    }

    public function driver_list_search($string) {
        $query = $this->db->query("select * from driver_data where name  like '%$string%'  or email  like '%$string%'");

        //$query = $this->db->query("select * from client_data where name  like '%$string%'  or email  like '%$string%'");


        return $query->result();
    }

    public function addadmin($username, $password) {
        $query = $this->db->query("insert into admin (username,pass) values('$username','$password')");
        if ($query) {
            return 1;
        } else {
            return 0;
        }
    }

    public function updateoper($operator) {
        $query = $this->db->query("UPDATE operator_no SET operator='$operator' WHERE 1");
    }

    public function delete_user($eid) {
        $eid=array_filter($eid);
        if (empty($eid)) {
            redirect('users');
        } else if (is_array($eid)) {
            $id = implode(',', $eid);
        } else {
            $id = $eid;
        }
        $query = $this->db->query("delete from client_data where client_id IN($id)");

        if ($query) {
            return 1;
        } else {
            return 0;
        }
    }

    public function delete_driver($eid) {
        $eid=array_filter($eid);
        if (empty($eid)) {
            redirect('users/driver');
        } else if (is_array($eid)) {
            $id = implode(',', $eid);
        } else {
            $id = $eid;
        }
        $query = $this->db->query("delete from driver_data where driver_id IN($id)");

        if ($query) {
            return 1;
        } else {
            return 0;
        }
    }

    public function aprove_driver($eid) {

        $query = $this->db->query("select * from driver_data where driver_id='$eid'");
        $data = $query->result();
        $result = trim($data[0]->confirm_status);
        //echo  $result;
        if ($result == 0) {
            // echo "result 0";
            $sql = "update driver_data set confirm_status ='1' where driver_id='$eid'";
            //echo $sql;
            $query1 = $this->db->query($sql);
        } else {
            // echo "result not equal to 0";
            $sql1 = "update driver_data set confirm_status ='0' where driver_id='$eid'";
            //echo $sql1;
            $query1 = $this->db->query($sql1);
        }

        if ($query1) {
            return 1;
        } else {
            return 0;
        }
    }

    public function user_history($user_id, $is_driver) {
        if ($is_driver == 0) {
            $query = $this->db->query("SELECT "
                    . "client_request_data.random_id, "
                    . "client_request_data.lattitude, "
                    . "client_request_data.logitude, "
                    . "client_request_data.client_id, "
                    . "client_request_data.driver_id, "
                    . "client_request_data.time_of_pickup, "
                    . "client_request_data.end_lat AS end_lattitude, "
                    . "client_request_data.end_long AS end_logitude, "
                    . "driver_data.name AS 'driver_name', "
                    . "client_data.name AS 'client_name' "
                    . "FROM client_request_data "
                    . "LEFT JOIN client_data ON client_request_data.client_id = client_data.client_id "
                    . "LEFT JOIN driver_data ON client_request_data.driver_id = driver_data.driver_id "
                    . "WHERE client_request_data.client_id = '$user_id' AND "
                    . "client_request_data.complete_status='1' AND "
                    . "client_request_data.request_status='1' AND "
                    . "client_request_data.cancel_flg='0' ORDER BY client_request_data.request_id DESC");
        } else {
            $query = $this->db->query("SELECT "
                    . "client_request_data.random_id, "
                    . "client_request_data.lattitude, "
                    . "client_request_data.logitude, "
                    . "client_request_data.client_id, "
                    . "client_request_data.driver_id, "
                    . "client_request_data.time_of_pickup, "
                    . "client_request_data.end_lat AS end_lattitude, "
                    . "client_request_data.end_long AS end_logitude, "
                    . "driver_data.name AS 'driver_name', "
                    . "client_data.name AS 'client_name' "
                    . "FROM client_request_data "
                    . "LEFT JOIN client_data ON client_request_data.client_id = client_data.client_id "
                    . "LEFT JOIN driver_data ON client_request_data.driver_id = driver_data.driver_id "
                    . "WHERE client_request_data.driver_id = '$user_id' AND "
                    . "client_request_data.complete_status='1' AND "
                    . "client_request_data.request_status='1' AND "
                    . "client_request_data.cancel_flg='0' ORDER BY client_request_data.request_id DESC");
        }
        //$query = $this->db->query("select * from client_data where name  like '%$string%'  or email  like '%$string%'");


        return $query->result();
    }

    public function detail_history_path_point($root_id) {
        $query = $this->db->query("SELECT "
                . "client_request_data.random_id, "
                . "client_request_data.lattitude, "
                . "client_request_data.logitude, "
                . "client_request_data.client_id, "
                . "client_request_data.driver_id, "
                . "client_request_data.time_of_pickup, "
                . "client_request_data.end_lat AS end_lattitude, "
                . "client_request_data.end_long AS end_logitude, "
                . "driver_data.name AS 'driver_name', "
                . "client_data.name AS 'client_name' "
                . "FROM client_request_data "
                . "LEFT JOIN client_data ON client_request_data.client_id = client_data.client_id "
                . "LEFT JOIN driver_data ON client_request_data.driver_id = driver_data.driver_id "
                . "WHERE client_request_data.random_id = '$root_id' AND "
                . "client_request_data.complete_status='1' AND "
                . "client_request_data.request_status='1' AND "
                . "client_request_data.cancel_flg='0' ORDER BY client_request_data.request_id DESC");
        return $query->result();
    }

    public function get_about_us() {
        $query = $this->db->query("select * from about_us");

        //$query = $this->db->query("select * from client_data where name  like '%$string%'  or email  like '%$string%'");


        return $query->result();
    }

    public function updateabout($id, $data, $link_1, $link_2) {
        $query = $this->db->query("UPDATE `about_us` SET `about`='$data',`link_1`='$link_1',`link_2`='$link_2' WHERE `id`='$id'");
    }

}