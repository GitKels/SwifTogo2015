<?php

session_start();
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
define('GOOGLE_API_KEY', 'AIzaSyCt6yvHeJwZj7vpp2nHKCQO76e7Hm_j9Kk');

class users extends CI_Controller {
    /* client_certificate */

    public $ctx_client;
    public $fp_client;
    public $ssl_client = 'ssl://gateway.push.apple.com:2195';
    public $passphrase_client = "AppDupe123!";
    public $sandboxCertificate_client = '../ws/certy/UberUser.pem';
    public $sandboxSsl_client = 'ssl://gateway.sandbox.push.apple.com:2195';
    public $sandboxFeedback_client = 'ssl://feedback.sandbox.push.apple.com:2196';
    public $message_client = "ManagerMaster";
    /* Driver_certificate */
    public $ctx_driver;
    public $fp_driver;
    public $ssl_driver = 'ssl://gateway.push.apple.com:2195';
    public $passphrase_driver = "AppDupe123!";
    public $sandboxCertificate_driver = '../ws/certy/UberDriver.pem';
    public $sandboxSsl_driver = 'ssl://gateway.sandbox.push.apple.com:2195';
    public $sandboxFeedback_driver = 'ssl://feedback.sandbox.push.apple.com:2196';
    public $message_driver = "ManagerMaster";

    function __construct() {
        parent::__construct();
        if ($this->session->userdata('login') == FALSE) {
            redirect('login');
        }
        /* $this->initialize_apns_client(); */
        /* $this->initialize_apns_driver(); */
    }

    public function initialize_apns_client() {
        $this->ctx_client = stream_context_create();

        //stream_context_set_option($ctx, 'ssl', 'cafile', 'entrust_2048_ca.cer');

        stream_context_set_option($this->ctx_client, 'ssl', 'local_cert', $this->sandboxCertificate_client);
        stream_context_set_option($this->ctx_client, 'ssl', 'passphrase', $this->passphrase_client); // use this if you are using a passphrase
        // Open a connection to the APNS servers

        $this->fp_client = @stream_socket_client($this->sandboxSsl_client, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $this->ctx_client);

        //		$this->fp_client = @stream_socket_client(
        //			$this->sandboxSsl_client, $err,
        //			$errstr, 600, STREAM_CLIENT_CONNECT, $this->ctx);	

        if ($this->fp_client) {
            /* echo "<br>successfully connected to server of Apns<br>"; */
        } else {
            /* echo "<br>Error in connection in apns file<br>"; */
        }
    }

    public function initialize_apns_driver() {
        $this->ctx_driver = stream_context_create();

        //stream_context_set_option($ctx, 'ssl', 'cafile', 'entrust_2048_ca.cer');

        stream_context_set_option($this->ctx_driver, 'ssl', 'local_cert', $this->sandboxCertificate_driver);
        stream_context_set_option($this->ctx_driver, 'ssl', 'passphrase', $this->passphrase_driver); // use this if you are using a passphrase
        // Open a connection to the APNS servers

        $this->fp_driver = @stream_socket_client($this->sandboxSsl_driver, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $this->ctx_driver);

        //		$this->fp_driver = @stream_socket_driver(
        //			$this->sandboxSsl_driver, $err,
        //			$errstr, 600, STREAM_CLIENT_CONNECT, $this->ctx);	

        if ($this->fp_driver) {
            /* echo "<br>successfully connected to server of Apns<br>"; */
        } else {
            /* echo "<br>Error in connection in apns file<br>"; */
        }
    }

    public function send_PUSH_CLIENT($result1, $message) {
        $this->initialize_apns_client();
        $errCounter = 0;
        //$result1 = explode(",", $result1);		
        //$msg = "Yes..e-lluminati";
        if (!isset($message["id"]) || empty($message["id"])) {
            $id = "";
        } else {
            $id = $message["id"];
        }
        if ($id == '4') {
            if (!isset($message["random_id"]) || empty($message["random_id"])) {
                $root_id = "";
            } else {
                $root_id = $message["random_id"];
            }
        }
        /* print_r($message); */
        $payload = '{ "aps" :  { "alert" : "A request was terminated by admin, Please try again...",'
                . ' "random_id" : "' . $root_id . '", '
                . '"id":"' . $id . '", '
                . '"badge" : 1, "sound" : "default" } }';

        /* array of aps send as message */
        /* $body['aps'] = array('alert' => $message, 'price' => $message,'badge'=> 1,'sound'=>"default");
          $payload = json_encode($body); */


        $result = 0;
        $bodyError = "";
        /* print_r($payload); */
        foreach ($result1 as $key => $value) {
            $msg = chr(0) . pack("n", 32) . pack('H*', str_replace(' ', '', $value)) . pack('n', (strlen($payload))) . $payload;

            $result = fwrite($this->fp_client, $msg);

            $bodyError .= 'result: ' . $result . ', devicetoken: ' . $value;

            if (!$result) {
                $errCounter = $errCounter + 1;
                // send an email to your address if you want to know if something went wrong...
                // mail('YOUR EMAIL ADDRESS', 'FORTIMO PUSH APNS FAILED', 'result: '.$result.', devicetoken: '.$deviceToken[0]);
            }
        }

        //echo "<br>errors : $errCounter";

        if ($result) {
            /* echo '<br>Delivered Message to APNS' . PHP_EOL; */
            $bool_result = true;
        } else {
            /* echo '<br>Could not Deliver Message to APNS' . PHP_EOL; */
            $bool_result = false;
        }

        @socket_close($this->fp_client);
        @fclose($this->fp_client);

        return $bool_result;
        //return $bodyError;
    }

    public function send_PUSH_DRIVER($result1, $message) {
        $this->initialize_apns_driver();
        /* print_r($result1);
          print_r($message); */
        $errCounter = 0;
        //$result1 = explode(",", $result1);		
        //$msg = "Yes..e-lluminati";

        /* print_r($message); */
        if (!isset($message["id"]) || empty($message["id"])) {
            $id = "";
        } else {
            $id = $message["id"];
        }
        if ($id == '1') {
            if (!isset($message["random_id"]) || empty($message["random_id"])) {
                $root_id = "";
            } else {
                $root_id = $message["random_id"];
            }
            if (!isset($message["lattitude"]) || empty($message["lattitude"])) {
                $root_lat = "";
            } else {
                $root_lat = $message["lattitude"];
            }
            if (!isset($message["logitude"]) || empty($message["logitude"])) {
                $root_long = "";
            } else {
                $root_long = $message["logitude"];
            }
            if (!isset($message["client_contact"]) || empty($message["client_contact"])) {
                $client_number = "";
            } else {
                $client_number = $message["client_contact"];
            }
            if (!isset($message["operator_contact"]) || empty($message["operator_contact"])) {
                $operator_number = "";
            } else {
                $operator_number = $message["operator_contact"];
            }
            if (!isset($message["client_name"]) || empty($message["client_name"])) {
                $client_nm = "";
            } else {
                $client_nm = $message["client_name"];
            }
            $payload = '{ "aps" :  { "alert" : "A request is assign to you.",'
                    . ' "random_id" : "' . $root_id . '", '
                    . '"lattitude":"' . $root_lat . '", '
                    . '"logitude":"' . $root_long . '", '
                    . ' "client_contact":"' . $client_number . '", '
                    . ' "operator_contact":"' . $operator_number . '", '
                    . ' "client_name":"' . $client_nm . '", '
                    . '"id":"' . $id . '", '
                    . '"badge" : 1, "sound" : "default" } }';
        } else if ($id == '2') {
            if (!isset($message["random_id"]) || empty($message["random_id"])) {
                $root_id = "";
            } else {
                $root_id = $message["random_id"];
            }
            $payload = '{ "aps" :  { "alert" : "A request was terminated by admin, Please try again...",'
                    . ' "random_id" : "' . $root_id . '", '
                    . '"id":"' . $id . '", '
                    . '"badge" : 1, "sound" : "default" } }';
        }




        /* array of aps send as message */
        /* $body['aps'] = array('alert' => $message, 'price' => $message,'badge'=> 1,'sound'=>"default");
          $payload = json_encode($body); */


        $result = 0;
        $bodyError = "";
        /* print_r($payload); */
        foreach ($result1 as $key => $value) {
            $msg = chr(0) . pack("n", 32) . pack('H*', str_replace(' ', '', $value)) . pack('n', (strlen($payload))) . $payload;
            $result = fwrite($this->fp_driver, $msg);
            $bodyError .= 'result: ' . $result . ', devicetoken: ' . $value;

            if (!$result) {
                $errCounter = $errCounter + 1;
                // send an email to your address if you want to know if something went wrong...
                // mail('YOUR EMAIL ADDRESS', 'FORTIMO PUSH APNS FAILED', 'result: '.$result.', devicetoken: '.$deviceToken[0]);
            }
        }

        //echo "<br>errors : $errCounter";

        if ($result) {
            /* echo '<br>Delivered Message to APNS' . PHP_EOL; */
            $bool_result = true;
        } else {
            /* echo '<br>Could not Deliver Message to APNS' . PHP_EOL; */
            $bool_result = false;
        }

        @socket_close($this->fp_driver);
        @fclose($this->fp_driver);

        return $bool_result;
        //return $bodyError;
    }

    public function index() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->client_list();
        $this->load->view('header');
        $this->load->view('users', $data);
        $this->load->view('footer');
    }

    public function driver() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->driver_list();
        $this->load->view('header');
        $this->load->view('driver', $data);
        $this->load->view('footer');
    }

    public function client_requests() {
        $this->load->model('data_model');
        $this->load->view('header_map');
        $this->load->view('client_request');
        $this->load->view('footer_map');
    }

    public function driver_aprove() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->driver_aprove();
        $this->load->view('header');
        $this->load->view('driver', $data);
        $this->load->view('footer');
    }

    public function driver_pendding() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->driver_pendding();
        $this->load->view('header');
        $this->load->view('driver', $data);
        $this->load->view('footer');
    }

    public function feedback() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->feedback_list();
        $this->load->view('header');
        $this->load->view('feedback', $data);
        $this->load->view('footer');
    }

    public function jobcompleted() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->jobcompleted();
        $this->load->view('header');
        $this->load->view('jobcompleted', $data);
        $this->load->view('footer');
    }

    public function only_jobcompleted() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->only_jobcompleted();
        $this->load->view('header');
        $this->load->view('jobcompleted', $data);
        $this->load->view('footer');
    }

    public function not_jobcompleted() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->not_jobcompleted();
        $this->load->view('header');
        $this->load->view('jobcompleted', $data);
        $this->load->view('footer');
    }

    public function parseToXML($htmlStr) {
        $xmlStr = str_replace('<', '&lt;', $htmlStr);
        $xmlStr = str_replace('>', '&gt;', $xmlStr);
        $xmlStr = str_replace('"', '&quot;', $xmlStr);
        $xmlStr = str_replace("'", '&#39;', $xmlStr);
        $xmlStr = str_replace("&", '&amp;', $xmlStr);
        return $xmlStr;
    }

    public function client_pin_ajax() {
        $query = "SELECT "
                . "client_data.name, "
                . "client_data.contact, "
                . "client_data.country_code, "
                . "client_data.email, "
                . "client_request_data.random_id, "
                . "client_request_data.lattitude, "
                . "client_request_data.logitude "
                . "FROM client_request_data "
                . "LEFT JOIN client_data ON client_request_data.client_id=client_data.client_id "
                . "WHERE client_request_data.driver_id='0' AND "
                . "client_request_data.request_status ='0' AND "
                . "client_request_data.cancel_flg = '0' AND "
                . "client_request_data.complete_status = '0' ";
        $result = mysql_query($query);
        if (!$result) {
            die('Invalid query: ' . mysql_error());
        }
        /* $this->load->view('phpsqlajax_genxml', $data); */
        header("Content-type: text/xml");
        // Start XML file, echo parent node
        echo '<markers>';

        // Iterate through the rows, printing XML nodes for each
        /* print_r ($result); */
        while ($row = @mysql_fetch_assoc($result)) {
            $client_name = $row['name'];
            $contact = $row['country_code'] . $row['contact'];
            $email = $row['email'];
            // ADD TO XML DOCUMENT NODE
            echo '<marker ';
            echo 'name="' . $this->parseToXML($row['random_id']) . '" ';
            echo 'client_name="' . $client_name . '" ';
            echo 'contact="' . $contact . '" ';
            echo 'email="' . $email . '" ';
            echo 'lat="' . $row['lattitude'] . '" ';
            echo 'lng="' . $row['logitude'] . '" ';
            echo 'type="client" ';
            echo '/>';
        }

        // End XML file
        echo '</markers>';
    }

    public function display_drivers_map() {
        $this->load->model('data_model');
        $this->load->view('driver_map');
        $this->load->view('display_driver');
        $this->load->view('footer_map');
        if (!isset($_GET["name"]) || empty($_GET["name"])) {
            redirect("users/client_requests");
        } else {
            $name = $_GET["name"];
        }
        $_SESSION['client_id'] = $name;
    }

    public function driver_pin_ajax() {
        $client = $_SESSION['client_id'];
        $query = "SELECT "
                . "client_data.name, "
                . "client_data.contact, "
                . "client_data.country_code, "
                . "client_data.email, "
                . "client_request_data.random_id, "
                . "client_request_data.lattitude, "
                . "client_request_data.logitude "
                . "FROM client_request_data "
                . "LEFT JOIN client_data ON client_request_data.client_id=client_data.client_id "
                . "WHERE client_request_data.driver_id='0' AND "
                . "client_request_data.request_status ='0' AND "
                . "client_request_data.cancel_flg = '0' AND "
                . "client_request_data.complete_status = '0' AND "
                . "client_request_data.random_id='$client'";
        $query_driver = "SELECT * FROM driver_data WHERE confirm_status='1' AND is_on_root='0' AND is_busy='0'";
        $result = mysql_query($query);
        $result_driver = mysql_query($query_driver);
        if (!$result) {
            die('Invalid query: ' . mysql_error());
        }
        if (!$result_driver) {
            die('Invalid query: ' . mysql_error());
        }
        /* $this->load->view('phpsqlajax_genxml', $data); */
        header("Content-type: text/xml");
        // Start XML file, echo parent node
        echo '<markers>';

        // Iterate through the rows, printing XML nodes for each

        while ($row = @mysql_fetch_assoc($result)) {
            $client_name = $row['name'];
            $contact = $row['country_code'] . $row['contact'];
            $email = $row['email'];
            // ADD TO XML DOCUMENT NODE
            echo '<marker ';
            echo 'name="' . $this->parseToXML($row['random_id']) . '" ';
            echo 'address="' . $this->parseToXML($row['random_id']) . '" ';
            echo 'client_name="' . $client_name . '" ';
            echo 'email="' . $email . '" ';

            echo 'contact="' . $contact . '" ';
            echo 'lat="' . $row['lattitude'] . '" ';
            echo 'lng="' . $row['logitude'] . '" ';
            echo 'type="client" ';
            echo '/>';
        }
        while ($row1 = @mysql_fetch_assoc($result_driver)) {
            // ADD TO XML DOCUMENT NODE
            $contact = $row1['country_code'] . $row1['contact'];
            $email = $row1['rating'];
            echo '<marker ';
            echo 'name="' . $this->parseToXML($row1['name']) . '" ';
            echo 'address="' . $this->parseToXML($row1['driver_id']) . '" ';
            echo 'contact="' . $contact . '" ';
            echo 'email="' . $email . '" ';
            echo 'lat="' . $row1['lattitude'] . '" ';
            echo 'lng="' . $row1['logitude'] . '" ';
            echo 'type="driver" ';
            echo '/>';
        }

        // End XML file
        echo '</markers>';
    }

    public function assign_driver() {
        if (!isset($_GET["driver_id"]) || empty($_GET["driver_id"])) {
            redirect("users/client_requests");
        } else {
            $driver_id = trim($_GET["driver_id"]);
            $unique_req_id = $_SESSION['client_id'];
            $update_request = "UPDATE client_request_data SET driver_id='$driver_id',request_status='1' WHERE random_id='$unique_req_id'";
            $result = mysql_query($update_request);
            $is_up = mysql_affected_rows();
            if ($is_up > 0) {
                $make_driver_busy = mysql_query("UPDATE driver_data SET is_on_root='1' WHERE driver_id='$driver_id'");
                $get_driver_data = mysql_query("SELECT * FROM driver_data WHERE driver_id='$driver_id'");
                while ($row = @mysql_fetch_assoc($get_driver_data)) {
                    $device_token = $row['device_token'];
                    $device_type = $row['device_type'];
                }
                $get_operator_data = mysql_query("SELECT * FROM operator_no LIMIT 1");
                $operator_number = "";
                while ($operator_row = @mysql_fetch_assoc($get_operator_data)) {
                    $operator_number = $operator_row['operator'];
                }
                $get_root = mysql_query("SELECT "
                        . "client_data.name, "
                        . "CONCAT(client_data.country_code,client_data.contact) AS contact, "
                        . "client_request_data.random_id, "
                        . "client_request_data.lattitude, "
                        . "client_request_data.logitude "
                        . "FROM client_request_data "
                        . "LEFT JOIN client_data ON client_request_data.client_id=client_data.client_id "
                        . "WHERE client_request_data.random_id='$unique_req_id'");
                if (mysql_num_rows($get_root) > 0) {
                    $row = @mysql_fetch_assoc($get_root);
                    $root_id = $row['random_id'];
                    $root_lat = $row['lattitude'];
                    $root_long = $row['logitude'];
                    $client = $row['contact'];
                    $client_nm = $row['name'];
                    $message = array("random_id" => $root_id, "lattitude" => $root_lat, "logitude" => $root_long, "client_contact" => "$client", "operator_contact" => "$operator_number", "client_name" => "$client_nm", "id" => "" . "1");
                    $and_push = array("message" => $message);
                    $device_token = array($device_token);
                    if ($device_type == 0) {
                        $noti = $this->send_GCM($device_token, $and_push);
                    } else {
                        $noti = $this->send_PUSH_DRIVER($device_token, $message);
                    }
                } else {
                    redirect("users/client_requests");
                }
                redirect("users/client_requests");
            } else {
                redirect("users/client_requests");
            }
        }
    }

    public function send_GCM($registatoin_ids, $message) {
        /* print_r($message); */
        // include config

        /* include_once 'config.php'; */
        // Set POST variables
        $url = 'https://android.googleapis.com/gcm/send';

        $fields = array(
            'registration_ids' => $registatoin_ids,
            'data' => $message,
        );

        $headers = array(
            'Authorization: key=' . GOOGLE_API_KEY,
            'Content-Type: application/json'
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        /* print_r($result); */
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        /* echo $result/*."\n\n".json_encode($fields); */
    }

    public function map_demo() {
        $this->load->library('googlemaps');

        $config['center'] = '37.4419, -122.1419';
        $config['zoom'] = 'auto';
        $this->googlemaps->initialize($config);

        $marker = array();
        $marker['position'] = '37.429, -122.1519';
        $marker['infowindow_content'] = '1 - Hello World!';
        $marker['icon'] = 'http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=A|9999FF|000000';
        $this->googlemaps->add_marker($marker);

        $marker = array();
        $marker['position'] = '37.409, -122.1319';
        $marker['draggable'] = TRUE;
        $marker['animation'] = 'DROP';
        $this->googlemaps->add_marker($marker);

        $marker = array();
        $marker['position'] = '37.449, -122.1419';
        $marker['onclick'] = 'alert("You just clicked me!!")';
        $this->googlemaps->add_marker($marker);
        $data['map'] = $this->googlemaps->create_map();

        $this->load->view('view_file', $data);
    }

    public function search() {
        $string = $_GET['q'];
        $type = $_GET['type'];

        if ($type != 'Driver') {
            $this->load->model('data_model');
            $data['users_list'] = $this->data_model->users_list_search($string);
            $this->load->view('header');
            $this->load->view('users', $data);
            $this->load->view('footer');
        } else {
            $this->load->model('data_model');
            $data['users_list'] = $this->data_model->driver_list_search($string);
            $this->load->view('header');
            $this->load->view('driver', $data);
            $this->load->view('footer');
        }
    }

    public function go_to_map() {
        $root_id = $_GET['id'];
        $_SESSION['disp_pin'] = $root_id;
        redirect("users/client_requests");
    }

    public function user_history() {
        $user_id = $_GET['id'];
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->user_history($user_id, 0);
        $this->load->view('header');
        $this->load->view('user_history', $data);
        $this->load->view('footer');
        /* mili to date
          $mil = 1357133639816;
          $seconds = $mil / 1000;
          echo date("d-m-Y H:i:s T", $seconds);
          $mil = 1227643821310;
          $seconds = $mil / 1000;
          echo date("d-m-Y", $seconds);
         */
    }

    public function driver_history() {
        $user_id = $_GET['id'];
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->user_history($user_id, 1);
        $this->load->view('header');
        $this->load->view('driver_history', $data);
        $this->load->view('footer');
    }

    public function detail_history() {
        $root_id = $_GET['id'];
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->detail_history_path_point($root_id);
        $this->load->view('detail_history_map', $data);
        $this->load->view('detail_history');
        $this->load->view('footer_map');
    }

    public function delete_request() {
        if (!isset($_GET["id"]) || empty($_GET["id"])) {
            redirect("users/jobcompleted");
        } else {
            $root_id = ($_GET["id"]);
            $root_info = mysql_query("SELECT "
                    . "client_request_data.random_id, "
                    . "client_request_data.client_id, "
                    . "client_request_data.driver_id, "
                    . "driver_data.device_type AS 'driver_device', "
                    . "driver_data.device_token AS 'driver_token', "
                    . "client_data.device_type AS 'client_device', "
                    . "client_data.devie_token AS 'client_token' "
                    . "FROM client_request_data "
                    . "LEFT JOIN client_data ON client_request_data.client_id = client_data.client_id "
                    . "LEFT JOIN driver_data ON client_request_data.driver_id = driver_data.driver_id "
                    . "WHERE client_request_data.random_id = '$root_id'");
            $remove_root = mysql_query("DELETE FROM client_request_data WHERE random_id = '$root_id'");
            $is_up = mysql_affected_rows();
            if ($is_up > 0) {
                while ($row = @mysql_fetch_assoc($root_info)) {
                    $driver_id = $row['driver_id'];
                    $request_id = $row['random_id'];
                    $driver_token = $row['driver_token'];
                    $driver_device = $row['driver_device'];
                    $client_token = $row['client_token'];
                    $client_device = $row['client_device'];
                }

                $message = array("random_id" => $request_id, "id" => "" . "2");
                $and_push = array("message" => $message);
                if (!isset($driver_token) || empty($driver_token)) {
                    
                } else {
                    $device_token = array($driver_token);
                    if ($driver_device == 0) {
                        $noti = $this->send_GCM($device_token, $and_push);
                    } else {
                        $noti = $this->send_PUSH_DRIVER($device_token, $message);
                    }
                    $update_driver_stat = mysql_query("UPDATE driver_data SET is_on_root='0' WHERE driver_id='$driver_id'");
                }
                $message_client = array("random_id" => $request_id, "id" => "" . "4");
                $and_push_client = array("message" => $message_client);
                $device_token_cleint = array($client_token);
                if ($client_device == 0) {
                    $noti = $this->send_GCM($device_token_cleint, $and_push_client);
                } else {
                    $noti = $this->send_PUSH_CLIENT($device_token_cleint, $message_client);
                }
                redirect("users/jobcompleted");
            } else {
                redirect("users/jobcompleted");
            }
        }
    }

    public function about_us() {
        $this->load->model('data_model');
        $data['users_list'] = $this->data_model->get_about_us();
        $this->load->view('header');
        $this->load->view('about_us', $data);
        $this->load->view('footer');
    }
    
    public function driver_arrange() {
        $arrng = $_GET['arrange'];

        /* echo $arrng; */
        /* echo ("select * from driver_data ORDER BY name $arrng"); */
        $all_drivers = $this->db->query("SELECT * FROM driver_data ORDER BY name $arrng");
        $users_list = $all_drivers->result();
        $base = base_url();
        foreach ($users_list as $user) {
            $devicetype = $user->device_type;
            if ($devicetype == 1) {
                $devicetype = "iPhone";
            } else {
                $devicetype = "Android";
            }
            $status = $user->confirm_status;
            if ($status == 1) {
                $status = "<span style='color:#005E20;'>Approved</span>";
                $statusadmin = "Decline";
            } else {
                $status = "<span style='color:#FF0000;'>Pending</span>";
                $statusadmin = "Approved";
            }
            $trip_stat = $user->is_on_root;
            if ($trip_stat == '1') {
                $driver_trip_stat = "On Trip";
            } else {
                $driver_trip_stat = "Free";
            }
            $avail_stat = $user->is_busy;
            if ($avail_stat == '1') {
                $is_driver_stat = "<span style='color:#FF0000;'>Not available</span>";
            } else {
                $is_driver_stat = "<span style='color:#005E20;'>Available</span>";
            }


            echo "<tr>"
            . "<td>"
            . "<input type='checkbox' id='customcheckbox1[]' name='customcheckbox1[]' value=' $user->driver_id  ' data-toggle='selectrow' data-target='tr' data-contextual='success'>"
            . "<label for='customcheckbox1'></label>"
            . "</td>"
            . "<td>" . $user->name . "</td>"
            . "<td>" . $user->email . "</td>"
            . "<td>" . $user->country_code . $user->contact . "</td>"
            . "<td>" . $user->gender . "</td>"
            . "<td>" . $user->rating . "</td>"
            . "<td>" . $user->total_trips . "</td>"
            . "<td>" . $driver_trip_stat . "</td>"
            . "<td>" . $devicetype . "</td>"
            . "<td>" . $status . "</td>"
            . "<td>" . $is_driver_stat . "</td>"
            . "<input type='hidden' name='eid' value='" . $user->driver_id . "'>"
            . "<td><button type='button' class='btn btn-green' onclick=\"location.href='" . $base . "index.php/users/driver_history?id=" . $user->driver_id . "'\">History</button></td>"
            . "<td class='text-center' style='border-right:0px;'>"
            . "<!-- button toolbar -->"
            . "<div class='toolbar'>"
            . "<div class='btn-group'>"
            . "<button type='submit' value='" . $user->driver_id . "' name='did' class='btn btn-nothing' onclick=\"return confirm('Are Your Sure Dlete It ?')\">Delete</button>"
            . "</div>"
            . "</div>"
            . "<!--/ button toolbar -->"
            . "</td>"
            . "<td class='text-center' style='border-left:0px'>"
            . "<!-- button toolbar -->"
            . "<div class='toolbar'>"
            . "<div class='btn-group'>"
            . "<button type='submit' value='" . $user->driver_id . "' name='aprove'id='aprove' class='btn btn-green'>$statusadmin</button>"
            . "</div>"
            . "</div>"
            . "<!--/ button toolbar -->"
            . "</td>"
            . "</form>"
            . "</tr>";
        }
    }

    public function users_arrange() {
        $arrng = $_GET['arrange'];

        /* echo $arrng; */
        /* echo ("select * from driver_data ORDER BY name $arrng"); */
        $all_drivers = $this->db->query("SELECT * FROM client_data ORDER BY name $arrng");
        $users_list = $all_drivers->result();
        $base = base_url();
        foreach ($users_list as $user) {
            $devicetype = $user->device_type;
            if ($devicetype == 1) {
                $devicetype = "iPhone";
            } else {
                $devicetype = "Android";
            }
            echo "<tr>"
            . "<td>"
            . "<input type='checkbox' id='customcheckbox1[]' name='customcheckbox1[]' value=' $user->client_id  ' data-toggle='selectrow' data-target='tr' data-contextual='success'>"
            . "<label for='customcheckbox1'></label>"
            . "</td>"
            . "<td>" . $user->name . "</td>"
            . "<td>" . $user->email . "</td>"
            . "<td>" . $user->country_code . $user->contact . "</td>"
            . "<td>" . $user->gender . "</td>"
            . "<td>" . $user->total_trips . "</td>"
            . "<td>" . $devicetype . "</td>"
            . "<input type='hidden' name='eid' value='" . $user->client_id . "'>"
            . "<td class='text-center'>"
            . "<button type='button' class='btn btn-green' onclick=\"location.href='" . $base . "index.php/users/user_history?id=" . $user->client_id . "'\">History</button>"
            . "</td>"
            . "<td class='text-center'>"
            . "<!-- button toolbar -->"
            . "<div class='toolbar'>"
            . "<div class='btn-group'>"
            . "<button type='submit' value='" . $user->client_id . "' name='cid' class='btn btn-nothing' onclick=\"return confirm('Are Your Sure Dlete It ?')\">Delete</button>"
            . "</div>"
            . "</div>"
            . "<!--/ button toolbar -->"
            . "</td>"
            . "</form>"
            . "</tr>";
        }
    }

    public function driver_job_arrange() {
        $arrng = $_GET['arrange'];

        /* echo $arrng; */
        /* echo ("select * from driver_data ORDER BY name $arrng"); */
        $all_drivers = $this->db->query("select *,"
                . "(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as drivername,"
                . "(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname "
                . "from client_request_data fd ORDER BY drivername $arrng");
        $users_list = $all_drivers->result();

        $base = base_url();

        function mili_to_time($milis) {
            $hours = (int) (($milis / (1000 * 60 * 60)) % 24);
            $minutes = (int) (($milis / (1000 * 60)) % 60);
            $seconds = (int) ($milis / 1000) % 60;
            $time = $hours . ":" . $minutes . ":" . $seconds;
            return $time;
        }

        foreach ($users_list as $user) {
            $root_id = $user->random_id;
            $status = $user->complete_status;
            if ($status == '1') {
                $status = "Completed";
                $root_id = "<a href='" . $base . "index.php/users/detail_history?id=" . $root_id . "' alt='link to map'>" . $root_id . "</a>";
                $button_link = "\"alert('Sorry, you can not delete completed request.')\"";
            } else {
                $status = "Incomplete";
                $root_id = "<a href='" . $base . "index.php/users/go_to_map?id=" . $user->random_id . "' alt='link to map'>" . $root_id . "</a>";
                $button_link = "\"location.href='" . $base . "index.php/users/delete_request?id=" . $user->random_id . "'\"";
            }
            $driver = $user->drivername;
            if (!isset($driver) || empty($driver)) {
                $driver = "<span style='color:#FF0000;'>Not Assigned</span>";
            } else {
                $driver = $user->drivername;
            }
            $mil = mili_to_time($user->time_of_pickup);
            $dat = date('Y-m-d H:i:s', strtotime($user->request_time));
            echo "<tr>"
            . "<td> $user->request_id </td>"
            . "<td>" . $root_id . "</td>"
            . "<td>" . $driver . "</td>"
            . "<td>" . $user->clientname . "</td>"
            . "<td>" . $dat . "</td>"
            . "<td>" . $mil . "</td>"
            . "<td>" . $status . "</td>"
            . "<td class='text-center'>"
            . "<!-- button toolbar -->"
            . "<div class='toolbar'>"
            . "<div class='btn-group'>"
            . "<button type='button' value='" . $user->client_id . "' name='cid' class='btn btn-nothing' onclick=" . $button_link . ">Delete</button>"
            . "</div>"
            . "</div>"
            . "<!--/ button toolbar -->"
            . "</td></tr>";
        }
    }

    public function user_job_arrange() {
        $arrng = $_GET['arrange'];

        /* echo $arrng; */
        /* echo ("select * from driver_data ORDER BY name $arrng"); */
        $all_drivers = $this->db->query("select *,"
                . "(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as drivername,"
                . "(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname "
                . "from client_request_data fd ORDER BY clientname $arrng");
        $users_list = $all_drivers->result();

        $base = base_url();

        function mili_to_time($milis) {
            $hours = (int) (($milis / (1000 * 60 * 60)) % 24);
            $minutes = (int) (($milis / (1000 * 60)) % 60);
            $seconds = (int) ($milis / 1000) % 60;
            $time = $hours . ":" . $minutes . ":" . $seconds;
            return $time;
        }

        foreach ($users_list as $user) {
            $root_id = $user->random_id;
            $status = $user->complete_status;
            if ($status == '1') {
                $status = "Completed";
                $root_id = "<a href='" . $base . "index.php/users/detail_history?id=" . $root_id . "' alt='link to map'>" . $root_id . "</a>";
                $button_link = "\"alert('Sorry, you can not delete completed request.')\"";
            } else {
                $status = "Incomplete";
                $root_id = "<a href='" . $base . "index.php/users/go_to_map?id=" . $user->random_id . "' alt='link to map'>" . $root_id . "</a>";
                $button_link = "\"location.href='" . $base . "index.php/users/delete_request?id=" . $user->random_id . "'\"";
            }
            $driver = $user->drivername;
            if (!isset($driver) || empty($driver)) {
                $driver = "<span style='color:#FF0000;'>Not Assigned</span>";
            } else {
                $driver = $user->drivername;
            }
            $mil = mili_to_time($user->time_of_pickup);
            $dat = date('Y-m-d H:i:s', strtotime($user->request_time));
            echo "<tr>"
            . "<td> $user->request_id </td>"
            . "<td>" . $root_id . "</td>"
            . "<td>" . $driver . "</td>"
            . "<td>" . $user->clientname . "</td>"
            . "<td>" . $dat . "</td>"
            . "<td>" . $mil . "</td>"
            . "<td>" . $status . "</td>"
            . "<td class='text-center'>"
            . "<!-- button toolbar -->"
            . "<div class='toolbar'>"
            . "<div class='btn-group'>"
            . "<button type='button' value='" . $user->client_id . "' name='cid' class='btn btn-nothing' onclick=" . $button_link . ">Delete</button>"
            . "</div>"
            . "</div>"
            . "<!--/ button toolbar -->"
            . "</td></tr>";
        }
    }

    public function complete_arrange() {
        $arrng = $_GET['arrange'];

        /* echo $arrng; */
        /* echo ("select * from driver_data ORDER BY name $arrng"); */
        $all_drivers = $this->db->query("select *,"
                . "(select dr.name from driver_data dr where dr.driver_id = fd.driver_id) as drivername,"
                . "(select cl.name from client_data cl where cl.client_id = fd.client_id) as clientname "
                . "from client_request_data fd ORDER BY complete_status $arrng");
        $users_list = $all_drivers->result();

        $base = base_url();

        function mili_to_time($milis) {
            $hours = (int) (($milis / (1000 * 60 * 60)) % 24);
            $minutes = (int) (($milis / (1000 * 60)) % 60);
            $seconds = (int) ($milis / 1000) % 60;
            $time = $hours . ":" . $minutes . ":" . $seconds;
            return $time;
        }

        foreach ($users_list as $user) {
            $root_id = $user->random_id;
            $status = $user->complete_status;
            if ($status == '1') {
                $status = "Completed";
                $root_id = "<a href='" . $base . "index.php/users/detail_history?id=" . $root_id . "' alt='link to map'>" . $root_id . "</a>";
                $button_link = "\"alert('Sorry, you can not delete completed request.')\"";
            } else {
                $status = "Incomplete";
                $root_id = "<a href='" . $base . "index.php/users/go_to_map?id=" . $user->random_id . "' alt='link to map'>" . $root_id . "</a>";
                $button_link = "\"location.href='" . $base . "index.php/users/delete_request?id=" . $user->random_id . "'\"";
            }
            $driver = $user->drivername;
            if (!isset($driver) || empty($driver)) {
                $driver = "<span style='color:#FF0000;'>Not Assigned</span>";
            } else {
                $driver = $user->drivername;
            }
            $mil = mili_to_time($user->time_of_pickup);
            $dat = date('Y-m-d H:i:s', strtotime($user->request_time));
            echo "<tr>"
            . "<td> $user->request_id </td>"
            . "<td>" . $root_id . "</td>"
            . "<td>" . $driver . "</td>"
            . "<td>" . $user->clientname . "</td>"
            . "<td>" . $dat . "</td>"
            . "<td>" . $mil . "</td>"
            . "<td>" . $status . "</td>"
            . "<td class='text-center'>"
            . "<!-- button toolbar -->"
            . "<div class='toolbar'>"
            . "<div class='btn-group'>"
            . "<button type='button' value='" . $user->client_id . "' name='cid' class='btn btn-nothing' onclick=" . $button_link . ">Delete</button>"
            . "</div>"
            . "</div>"
            . "<!--/ button toolbar -->"
            . "</td></tr>";
        }
    }

}
