<?php

class data_controller extends CI_Controller {

    function __construct() {
        parent::__construct();
        if ($this->session->userdata('login') == FALSE) {
            echo "403 Forbidden Authentication Failed";
        } else {
            $this->load->model('data_model');
        }
    }

    public function new_users_count() {
        $day[1] = $this->data_model->users_count_date(date("Y-m-d", strtotime(' -6 day')));
        $day[2] = $this->data_model->users_count_date(date("Y-m-d", strtotime(' -5 day')));
        $day[3] = $this->data_model->users_count_date(date("Y-m-d", strtotime(' -4 day')));
        $day[4] = $this->data_model->users_count_date(date("Y-m-d", strtotime(' -3 day')));
        $day[5] = $this->data_model->users_count_date(date("Y-m-d", strtotime(' -2 day')));
        $day[6] = $this->data_model->users_count_date(date("Y-m-d", strtotime(' -1 day')));
        $day[7] = $this->data_model->users_count_date(date("Y-m-d"));


        $array = array($day[1], $day[2], $day[3], $day[4], $day[5], $day[6], $day[7]);
        echo json_encode($array);
    }

    public function online_users_count() {

        $day[1] = $this->data_model->online_users_count(date("Y-m-d", strtotime(' -6 day')));
        $day[2] = $this->data_model->online_users_count(date("Y-m-d", strtotime(' -5 day')));
        $day[3] = $this->data_model->online_users_count(date("Y-m-d", strtotime(' -4 day')));
        $day[4] = $this->data_model->online_users_count(date("Y-m-d", strtotime(' -3 day')));
        $day[5] = $this->data_model->online_users_count(date("Y-m-d", strtotime(' -2 day')));
        $day[6] = $this->data_model->online_users_count(date("Y-m-d", strtotime(' -1 day')));
        $day[7] = $this->data_model->online_users_count(date("Y-m-d"));


        $array = array($day[1], $day[2], $day[3], $day[4], $day[5], $day[6], $day[7]);
        echo json_encode($array);
    }

    public function offline_users_count() {

        $day[1] = $this->data_model->offline_users_count(date("Y-m-d", strtotime(' -6 day')));
        $day[2] = $this->data_model->offline_users_count(date("Y-m-d", strtotime(' -5 day')));
        $day[3] = $this->data_model->offline_users_count(date("Y-m-d", strtotime(' -4 day')));
        $day[4] = $this->data_model->offline_users_count(date("Y-m-d", strtotime(' -3 day')));
        $day[5] = $this->data_model->offline_users_count(date("Y-m-d", strtotime(' -2 day')));
        $day[6] = $this->data_model->offline_users_count(date("Y-m-d", strtotime(' -1 day')));
        $day[7] = $this->data_model->offline_users_count(date("Y-m-d"));


        $array = array($day[1], $day[2], $day[3], $day[4], $day[5], $day[6], $day[7]);
        echo json_encode($array);
    }

    public function delete_user() {
        $eid = $this->input->post('cid');

        $id = $this->input->post('customcheckbox1');

        if ($id == "") {
            $id = array($eid);
        }

        /*
          if ($this->data_model->delete_user($id)) {
          redirect('users');
          } else {
          echo 'failed';
          } */
    }

    public function delete_driver() {
        $eid = $this->input->post('did');
         //echo $eid;
         //exit;
        $id = $this->input->post('customcheckbox1');
        if ($id == "") {
            $id = array($eid);
        }
        $approve = $this->input->post('aprove');
        if ($approve != "") {
            if ($this->data_model->aprove_driver($approve)) {

               
                
               // print_R($data);
                redirect('users/driver');
            } else {
                echo 'failed';
            }
        } else {

            if ($this->data_model->delete_driver($id)) {
                redirect('users/driver');
            } else {
                echo 'failed';
            }
        }
    }

}
