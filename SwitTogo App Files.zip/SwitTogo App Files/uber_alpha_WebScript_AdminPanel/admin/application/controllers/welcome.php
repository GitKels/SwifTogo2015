<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Welcome extends CI_Controller {

    function __construct() {
        parent::__construct();
        if ($this->session->userdata('login') == FALSE) {
            redirect('login');
        }
    }

    public function index() {
        $data['check'] = $this->session->userdata('admin_username');
        $this->load->model('data_model');
        $data['sidebar'] = 'sidebar';
        $data['users_list'] = $this->data_model->users_list();
        $data['user_count_today'] = $this->data_model->users_count();
        $data['chat_count'] = $this->data_model->chat_count();
        $data['total_messages_date'] = $this->data_model->total_messages_date(date("Y-m-d"));
        $data['total_groups_date'] = $this->data_model->total_groups_date(date("Y-m-d"));
        /*$data['total_groups'] = $this->data_model->total_groups();*/
        $this->load->view('header');
        $this->load->view('index', $data);
        $this->load->view('footer');
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */