<?php

session_start();

class settings extends CI_Controller {

    function __construct() {
        parent::__construct();
        if ($this->session->userdata('login') == FALSE) {
            redirect('login');
        } else {
            $this->load->model('data_model');
        }
    }

    public function index() {

        $data['users_list'] = $this->data_model->users_list();
        $this->load->view('header');
        $this->load->view('settings', $data);
        $this->load->view('footer');
    }

    public function addadmin() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $repassword = $this->input->post('repassword');
        if ($password == $repassword) {
            if ($this->data_model->addadmin($username, $password)) {
                /* echo "success"; */
                $_SESSION['not_change'] = "<div style='color:#01802d; text-align: center; font-size: 13px;'>New user successfully created.</div>";
                redirect('settings');
            } else {
                /* echo "fails"; */
                $_SESSION['not_change'] = "<div style='color:#ff0000; text-align: center; font-size: 13px;'>New user not created, Please try again.</div>";
                redirect('settings');
            }
        } else {
            $_SESSION['not_change'] = "<div style='color:#ff0000; text-align: center; font-size: 13px;'>Passwords not metch.</div>";
            redirect('settings');
        }
    }

    public function updateoperator() {
        $operator = $this->input->post('operator');
        $operator_2 = $this->input->post('operator_copy');
        if ($operator == $operator_2) {
            $this->data_model->updateoper($operator);
            /* echo "success"; */
            $_SESSION['not_change'] = "<div style='color:#01802d; text-align: center; font-size: 13px;'>Operator number successfully changed.</div>";
            redirect('operator');
        } else {
            /* echo "fails"; */
            $_SESSION['not_change'] = "<div style='color:#ff0000; text-align: center; font-size: 13px;'>Both number are not same.</div>";
            redirect('operator');
        }
    }

    public function update_about() {
        $id = $this->input->post('ids');
        $data = $this->input->post('data');
        $link_1 = $this->input->post('link_1');
        $link_2 = $this->input->post('link_2');
        $data = nl2br($data);
        /* echo $id . " " . $data . " " . $link_1 . " " . $link_2; */
        $this->data_model->updateabout($id, $data, $link_1, $link_2);
        /* echo "success"; */
        $_SESSION['not_change'] = "<div style='color:#01802d; text-align: center; font-size: 13px;'>About-Us for mobile successfully changed.</div>";
        redirect('users/about_us');
    }

}