//
//  BaseVC.h
//  Uber
//
//  Created by Elluminati - macbook on 21/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseVC : UIViewController{
    
}
-(void)addBackButton;
-(void)gotoView:(id)vc;

@end
