//
//  UIImage+Additions_568.h
//  Qurate
//
//  Created by Igor Fedorov on 10/13/12.
//  Copyright (c) 2012 Igor Fedorov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Additions_568)

+ (void)patchImageNamedToSupport568Resources;

@end
