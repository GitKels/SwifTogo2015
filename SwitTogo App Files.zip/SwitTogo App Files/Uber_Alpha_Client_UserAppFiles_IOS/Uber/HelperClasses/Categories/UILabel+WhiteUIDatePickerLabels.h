//
//  UILabel+WhiteUIDatePickerLabels.h
//  Uber
//
//  Created by Elluminati - macbook on 03/07/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (WhiteUIDatePickerLabels)

@end
