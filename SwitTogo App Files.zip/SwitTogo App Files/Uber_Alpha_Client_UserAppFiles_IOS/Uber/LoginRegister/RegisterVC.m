//
//  RegisterVC.m
//  Uber
//
//  Created by Elluminati - macbook on 23/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "RegisterVC.h"

@interface RegisterVC ()

@end

@implementation RegisterVC

#pragma mark -
#pragma mark - Init

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //self.navigationItem.title=@"Register";
    }
    return self;
}

#pragma mark -
#pragma mark - ViewLife Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [super addBackButton];
    self.navigationItem.titleView=[[AppDelegate sharedAppDelegate]getHeader:[UIImage imageNamed:@"header_register_icon.png"]withTitle:TITLE_REGISTER];
    
    gender=GenderMale;

    self.txtDOB.inputView=self.viewPickDOB;
    self.txtCountryCode.inputView=self.viewCountryCode;

    if (!IS_IPHONE_5) {
        self.scrReg.contentSize=CGSizeMake(320, 480);
    }
    
    arrCountry=[[AppDelegate sharedAppDelegate]getCountry];
    [self.pickCountryCode reloadAllComponents];
}

#pragma mark -
#pragma mark - Actions

-(IBAction)onClickDone:(id)sende
{
    self.txtDOB.text=[[UtilityClass sharedObject]DateToString:self.pickDOB.date withFormate:DATE_FORMATE_DOB];
    [self.txtDOB resignFirstResponder];
    [self.txtCountryCode becomeFirstResponder];
}

-(IBAction)onClickDoneContryCode:(id)sender
{
    self.txtCountryCode.text=selectedCountry.phoneCode;
    [self.txtCountryCode resignFirstResponder];
    [self.txtMoNo becomeFirstResponder];
}

-(IBAction)onClickRegister:(id)sender
{
    [self textFieldShouldReturn:self.txtMoNo];
    
    if (self.txtUserName.text.length==0 || self.txtEmailID.text.length==0 || self.txtPsw.text.length==0 || self.txtMoNo.text.length==0 || self.txtDOB.text.length==0 || self.txtSex.text.length==0 || self.txtCountryCode.text==0)
    {
        [[UtilityClass sharedObject]showAlertWithTitle:@"Error!" andMessage:@"Plase enter all detail."];
        return;
    }
    
    if (![[UtilityClass sharedObject]isValidEmailAddress:self.txtEmailID.text])
    {
        [[UtilityClass sharedObject]showAlertWithTitle:@"Error!" andMessage:@"Plase enter valid email id."];
        return;
    }
    [self registerUser];
}

#pragma mark -
#pragma mark - Methods

-(void)registerUser
{
    NSString *strPath=FILE_CLIENT_REGISTER;
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setObject:self.txtUserName.text forKey:PARAM_NAME];
    [dictParam setObject:self.txtEmailID.text forKey:PARAM_EMAIL];
    [dictParam setObject:self.txtPsw.text forKey:PARAM_PASSWORD];
    [dictParam setObject:self.txtMoNo.text forKey:PARAM_CONTACT];
    [dictParam setObject:self.txtDOB.text forKey:PARAM_DATE_OF_BIRTH];
    
    [dictParam setObject:self.txtSex.text forKey:PARAM_GENDER];
    
    [dictParam setObject:self.txtCountryCode.text forKey:PARAM_COUNTRY_CODE];

    [dictParam setObject:DEVICE_TYPE forKey:PARAM_DEVICE_TYPE];
    [dictParam setObject:[[UserDefaultHelper sharedObject] deviceToken] forKey:PARAM_DEVICE_TOKEN];
    
    [[AppDelegate sharedAppDelegate]showHUDLoadingView:@""];
    
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    [afn getDataFromPath:strPath withParamData:dictParam withBlock:^(id response, NSError *error)
    {
        [[AppDelegate sharedAppDelegate]hideHUDLoadingView];
        if (response)
        {
            NSMutableDictionary *dict=[response objectForKey:WS_UBER_ALPHA];
            if ([[dict objectForKey:WS_STATUS]isEqualToString:WS_STATUS_SUCCESS])
            {
                [[User currentUser]setUser:[dict objectForKey:WS_DETAILS]];
                [[AppDelegate sharedAppDelegate]goToHome];
            }
            else{
                [[AppDelegate sharedAppDelegate]showToastMessage:[dict objectForKey:WS_MESSAGE]];
            }
        }
        else{
            [[AppDelegate sharedAppDelegate]showToastMessage:@"Server error, please try again"];
        }
    }];
}

#pragma mark -
#pragma mark - TextField Delegate

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    int y=0;
    if (textField==self.txtUserName)
    {
        
    }
    else if (textField==self.txtSex){
        
    }
    else if (textField==self.txtEmailID){
        
    }
    else if (textField==self.txtPsw)
    {
        y=50;
    }
    else if (textField==self.txtDOB)
    {
        y=100;
    }
    
    else if (textField==self.txtMoNo || textField==self.txtCountryCode)
    {
        y=150;
    }
    [self.scrReg setContentOffset:CGPointMake(0, y) animated:YES];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==self.txtUserName)
    {
        [self.txtSex becomeFirstResponder];
    }
    else if (textField==self.txtSex){
        [self.txtEmailID becomeFirstResponder];
    }
    else if (textField==self.txtEmailID)
    {
        [self.txtPsw becomeFirstResponder];
    }
    else if (textField==self.txtPsw)
    {
        [self.txtDOB becomeFirstResponder];
    }
    else if (textField==self.txtDOB)
    {
        [self.txtCountryCode becomeFirstResponder];
    }
    else if (textField==self.txtDOB)
    {
        [self.txtMoNo becomeFirstResponder];
    }
    else if (textField==self.txtMoNo)
    {
        [self.txtMoNo resignFirstResponder];
        [self.scrReg setContentOffset:CGPointMake(0, 0) animated:YES];
    }
    //[textField resignFirstResponder];
    return YES;
}

#pragma mark -
#pragma mark - UIPickerView Delegate

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [arrCountry count];
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    Country *contry=[arrCountry objectAtIndex:row];
    NSString *strTitle=[NSString stringWithFormat:@"%@ - %@",contry.phoneCode,contry.name];
    return strTitle;
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    selectedCountry=[arrCountry objectAtIndex:row];
}

#pragma mark -
#pragma mark - Memory Mgmt

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
