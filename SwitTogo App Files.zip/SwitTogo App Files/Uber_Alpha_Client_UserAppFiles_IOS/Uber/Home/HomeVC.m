//
//  HomeVC.m
//  Uber
//
//  Created by Elluminati - macbook on 21/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "HomeVC.h"
#import "FooterView.h"
#import "CallOperatorVC.h"
#import "ThankYouVC.h"
#import "FeedbackVC.h"

#import "Place.h"
#import "PlaceMark.h"


@interface HomeVC ()

@end

@implementation HomeVC

#pragma mark -
#pragma mark - Init

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title=@"Jobs";
    }
    return self;
}

+(HomeVC *)sharedObject
{
    static HomeVC *obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[HomeVC alloc] initWithNibName:@"HomeVC" bundle:nil];
    });
    return obj;
}

#pragma mark -
#pragma mark - ViewLife Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.titleView=[[AppDelegate sharedAppDelegate]getHeader:[UIImage imageNamed:@"header_location.png"]withTitle:TITLE_HOME];
    [self.btnService setTitle:BTN_TEXT_SERVICE forState:UIControlStateNormal];
    [self.btnService setTitle:BTN_TEXT_SERVICE forState:UIControlStateHighlighted];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationItem setHidesBackButton:YES];

    [self pushRecived];
}

#pragma mark -
#pragma mark - Methods

-(void)pushRecived
{
    [self setClientPushView];
}

-(void)setClientPushView
{
    if ([[ClientAssignment sharedObject]isActiveJob])
    {
        if([ClientAssignment sharedObject].pushClientID==PushClientIdJobDone)
        {
            //[super gotoView:[ThankYouVC sharedObject]];
            [super gotoView:[FeedbackVC sharedObject]];
        }
        else{
            [super gotoView:[CallOperatorVC sharedObject]];
            [[CallOperatorVC sharedObject]setData];
        }
    }
    else{
        Place* home = [[Place alloc] init];
        home.name = @"It's me";
        home.description = @"";
        home.latitude = [[[UserDefaultHelper sharedObject] currentLatitude] doubleValue];
        home.longitude = [[[UserDefaultHelper sharedObject] currentLongitude] doubleValue];
        home.isFrom=YES;
        [self showRouteFrom:home];
    }
}

#pragma mark -
#pragma mark - Actions

-(IBAction)onClickService:(id)sender
{
    //[super gotoView:[CallOperatorVC sharedObject]];
    
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setObject:[User currentUser].client_id forKey:PARAM_CLIENT_ID];
    [dictParam setObject:[[UserDefaultHelper sharedObject] currentLatitude] forKey:PARAM_LATTITUDE];
    [dictParam setObject:[[UserDefaultHelper sharedObject] currentLongitude] forKey:PARAM_LOGITUDE];
    
    AFNHelper *Afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    [Afn getDataFromPath:FILE_CLIENT_PICK_REQUEST withParamData:dictParam withBlock:^(id response, NSError *error)
    {
        if (response)
        {
            NSMutableDictionary *dictMain=[response objectForKey:WS_UBER_ALPHA];
            if ([[dictMain objectForKey:WS_STATUS]isEqualToString:WS_STATUS_SUCCESS])
            {
                PickUpRequest *pick=[[PickUpRequest alloc]init];
                [pick setData:[dictMain objectForKey:WS_DETAILS]];
                [CallOperatorVC sharedObject].pickUpReq=pick;
                [ClientAssignment sharedObject].random_id=pick.random_id;
                [super gotoView:[CallOperatorVC sharedObject]];
            }
        }
    }];
}

/*
 -(void)viewWillAppear:(BOOL)animated{
 [super viewWillAppear:animated];
 //[self.mapUser setCenterCoordinate:self.mapUser.userLocation.location.coordinate animated:YES];
 self.mapUser.showsUserLocation=YES;
 //MKCoordinateRegion myRegion=MKCoordinateRegionMakeWithDistance(self.mapUser.userLocation.location.coordinate, 1000, 1000);
 //[self.mapUser setRegion:myRegion animated:YES];
 }
 */
/*
 - (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
 MKCoordinateRegion region;
 MKCoordinateSpan span;
 span.latitudeDelta = 0.005;
 span.longitudeDelta = 0.005;
 CLLocationCoordinate2D location;
 location.latitude = userLocation.coordinate.latitude;
 location.longitude = userLocation.coordinate.longitude;
 region.span = span;
 region.center = location;
 
 MKCoordinateRegion myRegion=MKCoordinateRegionMakeWithDistance(self.mapUser.userLocation.location.coordinate, 1000, 1000);
 [mapView setRegion:myRegion animated:YES];
 }
 */

-(void)removeAllAnnotations
{
    [self.mapUser removeAnnotations:[self.mapUser annotations]];
}

-(void) showRouteFrom: (Place*) pickUp
{
    [self.mapUser removeAnnotations:[self.mapUser annotations]];
	PlaceMark* markPickUp = [[PlaceMark alloc] initWithPlace:pickUp];
	[self.mapUser addAnnotation:markPickUp];
	[self centerMap:pickUp];
}

-(void) centerMap: (Place*) pickUp
{
	MKCoordinateRegion region;
	region.center.latitude     = pickUp.latitude;
	region.center.longitude    = pickUp.longitude;
	region.span.latitudeDelta  = 0.1;
	region.span.longitudeDelta = 0.1;
	
	[self.mapUser setRegion:region animated:YES];
}

- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
    PlaceMark *place=(PlaceMark *)annotation;
    MKPinAnnotationView *newAnnotation = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"PlaceMark"];
    if (place.place.isFrom)
    {
        newAnnotation.pinColor = MKPinAnnotationColorRed;
    }
    else{
        newAnnotation.pinColor = MKPinAnnotationColorGreen;
    }
    /*
    if (![place.place.name isEqualToString:@"It's me"])
    {
        UIButton *btnSet=[UIButton buttonWithType:UIButtonTypeContactAdd];
        [btnSet addTarget:self action:@selector(onClicksetETA:) forControlEvents:UIControlEventTouchUpInside];
        newAnnotation.rightCalloutAccessoryView =btnSet;
    }
     */
    newAnnotation.animatesDrop = YES;
    newAnnotation.canShowCallout = YES;
    return newAnnotation;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
    
}

#pragma mark -
#pragma mark - Memory Mgmt

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
