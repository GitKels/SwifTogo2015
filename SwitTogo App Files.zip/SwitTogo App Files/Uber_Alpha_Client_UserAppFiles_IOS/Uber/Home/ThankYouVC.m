//
//  CallOperatorVC.m
//  Uber
//
//  Created by Elluminati - macbook on 30/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "ThankYouVC.h"
#import "FeedbackVC.h"

@interface ThankYouVC ()

@end

@implementation ThankYouVC

#pragma mark -
#pragma mark - Init

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title=@"Thank You";
    }
    return self;
}

+(ThankYouVC *)sharedObject
{
    static ThankYouVC *obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[ThankYouVC alloc] initWithNibName:@"ThankYouVC" bundle:nil];
    });
    return obj;
}

#pragma mark -
#pragma mark - ViewLife Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.titleView=[[AppDelegate sharedAppDelegate]getHeader:[UIImage imageNamed:@"header_eta_icon"]withTitle:TITLE_THANKYOU];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationItem setHidesBackButton:YES];
    [self setData];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [FeedbackVC sharedObject].clientAssignment=[[ClientAssignment alloc]initWithClientAssignment:[ClientAssignment sharedObject]];
    [[ClientAssignment sharedObject]removeAllData];
}

#pragma mark -
#pragma mark - Methods

-(void)setData
{
    self.lblRefNo.text=[NSString stringWithFormat:@"%@",[ClientAssignment sharedObject].random_id];
}

#pragma mark -
#pragma mark - Actions

-(IBAction)onClickFeedback:(id)sender
{
    [super gotoView:[FeedbackVC sharedObject]];
}

#pragma mark -
#pragma mark - Memory Mgmt

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
