//
//  FeedbackVC.m
//  Uber
//
//  Created by Elluminati - macbook on 09/07/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "FeedbackVC.h"
#import "HomeVC.h"

@interface FeedbackVC ()

@end

@implementation FeedbackVC

#pragma mark -
#pragma mark - Init

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

+(FeedbackVC *)sharedObject
{
    static FeedbackVC *obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[FeedbackVC alloc] initWithNibName:@"FeedbackVC" bundle:nil];
    });
    return obj;
}

#pragma mark -
#pragma mark - ViewLife Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.titleView=[[AppDelegate sharedAppDelegate]getHeader:[UIImage imageNamed:@"header_feedback_icon"]withTitle:TITLE_FEEDBACK];
    //[self.txtComments setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    for (int i=0; i<=5; i++)
    {
        UIButton *btnS=(UIButton *)[self.view viewWithTag:i+6000];
        [btnS setImage:[UIImage imageNamed:@"star_unrated"] forState:UIControlStateNormal];
        [btnS setImage:[UIImage imageNamed:@"star_rated"] forState:UIControlStateSelected];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationItem setHidesBackButton:YES];
    [self setData];
    rate=0;
}

#pragma mark -
#pragma mark - Methods

-(void)setData
{
    self.lblRefNo.text=[NSString stringWithFormat:@"%@",self.clientAssignment.random_id];
}

#pragma mark -
#pragma mark - Actions

-(IBAction)onClickBtnStar:(id)sender
{
    UIButton *btn=(UIButton *)sender;
    rate=(int)(btn.tag-6000);
    for (int i=0; i<=5; i++)
    {
        UIButton *btnS=(UIButton *)[self.view viewWithTag:i+6000];
        //[btnS setSelected:NO];
        
        if (i<=rate)
        {
            [btnS setSelected:YES];
        }
        else{
            [btnS setSelected:NO];
        }
    }
    [btn setSelected:YES];
}

-(IBAction)onClickRateService:(id)sender
{
    NSString *comment=@"";
    if (self.txtComments.text.length>0)
    {
        comment=self.txtComments.text;
    }
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setObject:self.clientAssignment.random_id forKey:PARAM_RANDOM_ID];
    [dictParam setObject:comment forKey:PARAM_COMMENT];
    [dictParam setObject:[NSString stringWithFormat:@"%d",rate] forKey:PARAM_RATING];
    
    [[AppDelegate sharedAppDelegate]showHUDLoadingView:@""];
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    [afn getDataFromPath:FILE_RATE_TRIP withParamData:dictParam withBlock:^(id response, NSError *error)
    {
        [[AppDelegate sharedAppDelegate]hideHUDLoadingView];
        if (response)
        {
            NSDictionary *dictUber=[response objectForKey:WS_UBER_ALPHA];
            [[AppDelegate sharedAppDelegate]showToastMessage:[dictUber objectForKey:WS_MESSAGE]];
            if ([[dictUber objectForKey:WS_STATUS]isEqualToString:WS_STATUS_SUCCESS]) {
                self.clientAssignment=nil;
                [super gotoView:[HomeVC sharedObject]];
            }
        }
    }];
}

#pragma mark -
#pragma mark - TextField Delegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark -
#pragma mark - Memory Mgmt

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
