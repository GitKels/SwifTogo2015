//
//  CallOperatorVC.h
//  Uber
//
//  Created by Elluminati - macbook on 30/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"
#import <MapKit/MapKit.h>

@interface CallOperatorVC : BaseVC<MKMapViewDelegate>
{
    NSTimer *timer;
    NSTimer *timerDriverLocation;
    BOOL isFeatchingDriverLocation;
    DriverInfo *driverInfo;
}
@property(nonatomic,weak)IBOutlet UIView *viewMap;
@property(nonatomic,weak)IBOutlet MKMapView *mapUser;
@property(nonatomic,weak)IBOutlet UIView *viewDetail;

@property(nonatomic,strong)PickUpRequest *pickUpReq;
@property(nonatomic,weak)IBOutlet UILabel *lblMsg;
@property(nonatomic,weak)IBOutlet UILabel *lblRefNo;

+(CallOperatorVC *)sharedObject;
-(IBAction)onClickCallOperator:(id)sender;
-(void)setData;

-(IBAction)onClickMap:(id)sender;
-(IBAction)onClickDetail:(id)sender;
-(IBAction)onClickCallDriver:(id)sender;

@end
