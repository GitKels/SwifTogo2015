//
//  CallOperatorVC.m
//  Uber
//
//  Created by Elluminati - macbook on 30/06/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "CallOperatorVC.h"
#import "ThankYouVC.h"
#import "FeedbackVC.h"

#import "Place.h"
#import "PlaceMark.h"

@interface CallOperatorVC ()

@end

@implementation CallOperatorVC

#pragma mark -
#pragma mark - Init

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title=@"Call Operator";
    }
    return self;
}

+(CallOperatorVC *)sharedObject
{
    static CallOperatorVC *obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[CallOperatorVC alloc] initWithNibName:@"CallOperatorVC" bundle:nil];
    });
    return obj;
}

#pragma mark -
#pragma mark - ViewLife Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.titleView=[[AppDelegate sharedAppDelegate]getHeader:[UIImage imageNamed:@"header_eta_icon"]withTitle:TITLE_CALLOPERATOR];
    
    self.viewMap.hidden=YES;
    self.viewDetail.hidden=NO;
    isFeatchingDriverLocation=NO;
    driverInfo=[[DriverInfo alloc]init];
    
    [self removeAllAnnotations];
    Place* home = [[Place alloc] init];
    home.name = @"It's me";
    home.description = @"";
    home.latitude = [[[UserDefaultHelper sharedObject] currentLatitude] doubleValue];
    home.longitude = [[[UserDefaultHelper sharedObject] currentLongitude] doubleValue];
    home.isFrom=YES;
    PlaceMark* markPickUp = [[PlaceMark alloc] initWithPlace:home];
	[self.mapUser addAnnotation:markPickUp];
    //[self addPinToMap:home];
    [self centerMap:self.mapUser];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationItem setHidesBackButton:YES];
    [self setData];
    
    if (timerDriverLocation)
    {
        [timerDriverLocation invalidate];
        timerDriverLocation=nil;
    }
    timerDriverLocation=[NSTimer scheduledTimerWithTimeInterval:15 target:self selector:@selector(getDriverLocation:) userInfo:nil repeats:YES];
}

-(void)viewWillDisappear:(BOOL)animated
{
    if (timer)
    {
        [timer invalidate];
        timer=nil;
    }
    if (timerDriverLocation)
    {
        [timerDriverLocation invalidate];
        timerDriverLocation=nil;
        isFeatchingDriverLocation=NO;
    }
    [super viewWillDisappear:animated];
}

#pragma mark -
#pragma mark - Methods

-(void)setData
{
    if (self.pickUpReq!=nil)
    {
        self.lblRefNo.text=[NSString stringWithFormat:@"%@",self.pickUpReq.random_id];
    }
    else{
        self.lblRefNo.text=[NSString stringWithFormat:@"%@",[ClientAssignment sharedObject].random_id];
    }
    if ([ClientAssignment sharedObject].pushClientID==PushClientIdPickUpTimeSet)
    {
        if (timer)
        {
            [timer invalidate];
            timer=nil;
        }
        timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changeTime:) userInfo:nil repeats:YES];
    }
    else if([ClientAssignment sharedObject].pushClientID==PushClientIdJobDone)
    {
        //[super gotoView:[ThankYouVC sharedObject]];
        [super gotoView:[FeedbackVC sharedObject]];
    }
    else{
        if ([ClientAssignment sharedObject].pushClientID==PushClientIdDriverReched)
        {
            self.lblMsg.text=LBL_TEXT_JOB_START;
        }
        else{
            self.lblMsg.text=LBL_TEXT_WAIT_DRIVER_RESPONSE;
        }
    }
}

-(void)changeTime:(id)sender
{
    self.lblMsg.text=[self getTimeDiffrent:[ClientAssignment sharedObject].dateETAClient];
}

-(NSString *)getTimeDiffrent:(NSDate *)date
{
    NSDate *dateA=[NSDate date];
    NSDate *dateB=date;
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                               fromDate:dateA
                                                 toDate:dateB
                                                options:0];
    NSInteger hour=components.hour;
    NSInteger minute=components.minute;
    NSInteger second=components.second;
    
    if (hour<0)
    {
        hour=0;
    }
    if (minute<0)
    {
        minute=0;
    }
    if (second<0)
    {
        second=0;
    }
    
    return [NSString stringWithFormat:@"%li:%li:%li",(long)hour, (long)minute, (long)second];
}

-(void)getDriverLocation:(id)sender
{
    if (!isFeatchingDriverLocation)
    {
        isFeatchingDriverLocation=YES;
        
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setObject:[ClientAssignment sharedObject].random_id forKey:PARAM_RANDOM_ID];
        
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_GET_DRIVER_LOCATION withParamData:dictParam withBlock:^(id response, NSError *error)
         {
             isFeatchingDriverLocation=NO;
             if (response)
             {
                 NSMutableDictionary *dictMain=[response objectForKey:WS_UBER_ALPHA];
                 if ([[dictMain objectForKey:WS_STATUS]isEqualToString:WS_STATUS_SUCCESS])
                 {
                     [driverInfo setData:dictMain];
                     [self removeAllAnnotations];
                     
                     Place* home = [[Place alloc] init];
                     home.name = @"It's me";
                     home.description = @"";
                     home.latitude = [[[UserDefaultHelper sharedObject] currentLatitude] doubleValue];
                     home.longitude = [[[UserDefaultHelper sharedObject] currentLongitude] doubleValue];
                     home.isFrom=YES;
                     //[self addPinToMap:home];
                     PlaceMark* markPickUp = [[PlaceMark alloc] initWithPlace:home];
                     [self.mapUser addAnnotation:markPickUp];
                     
                     Place *driver=[[Place alloc]init];
                     driver.name = driverInfo.name;
                     driver.description = driverInfo.contact;
                     driver.latitude = [driverInfo.lattitude doubleValue];
                     driver.longitude = [driverInfo.logitude doubleValue];
                     driver.isFrom=NO;
                     //[self addPinToMap:driver];
                     PlaceMark* markDriver = [[PlaceMark alloc] initWithPlace:driver];
                     [self.mapUser addAnnotation:markDriver];
                     [self centerMap:self.mapUser];
                 }
             }
         }];
    }
}


#pragma mark -
#pragma mark - Actions

-(IBAction)onClickMap:(id)sender
{
    self.viewMap.hidden=NO;
    self.viewDetail.hidden=YES;
}
-(IBAction)onClickDetail:(id)sender
{
    self.viewDetail.hidden=NO;
    self.viewMap.hidden=YES;
}

-(IBAction)onClickCallDriver:(id)sender
{
    if (driverInfo.contact!=nil)
    {
        NSString *phoneNumber = [@"tel://" stringByAppendingString:driverInfo.contact];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
    }
}

-(IBAction)onClickCallOperator:(id)sender
{
    [[AppDelegate sharedAppDelegate]showHUDLoadingView:@"Loading Operator Number"];
   
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    [afn getDataFromPath:FILE_GET_OPERATOR withParamData:nil withBlock:^(id response, NSError *error)
    {
        [[AppDelegate sharedAppDelegate]hideHUDLoadingView];
        if (response)
        {
            NSMutableDictionary *dictMain=[response objectForKey:WS_UBER_ALPHA];
            if ([[dictMain objectForKey:WS_STATUS]isEqualToString:WS_STATUS_SUCCESS])
            {
                NSArray *arrDetail=[dictMain objectForKey:WS_DETAILS];
                if ([arrDetail isKindOfClass:[NSArray class]])
                {
                    if ([arrDetail count]>0)
                    {
                        NSMutableDictionary *dict=[arrDetail objectAtIndex:0];
                        NSString *strNo=[dict objectForKey:@"operator"];
                    
                        NSString *phoneNumber = [@"tel://" stringByAppendingString:strNo];
                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
                    }
                }
            }
        }
    }];
}

#pragma mark -
#pragma mark - Map Methods

-(void)removeAllAnnotations
{
    [self.mapUser removeAnnotations:[self.mapUser annotations]];
}

-(void)addPinToMap:(Place*)pickUp
{
	PlaceMark* markPickUp = [[PlaceMark alloc] initWithPlace:pickUp];
	[self.mapUser addAnnotation:markPickUp];
	[self centerMap:self.mapUser];
}

- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
    PlaceMark *place=(PlaceMark *)annotation;
    MKPinAnnotationView *newAnnotation = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"PlaceMark"];
    if (place.place.isFrom)
    {
        newAnnotation.pinColor = MKPinAnnotationColorRed;
    }
    else{
        newAnnotation.pinColor = MKPinAnnotationColorGreen;
    }
    /*
     if (![place.place.name isEqualToString:@"It's me"])
     {
     UIButton *btnSet=[UIButton buttonWithType:UIButtonTypeContactAdd];
     [btnSet addTarget:self action:@selector(onClicksetETA:) forControlEvents:UIControlEventTouchUpInside];
     newAnnotation.rightCalloutAccessoryView =btnSet;
     }
     */
    newAnnotation.animatesDrop = NO;
    newAnnotation.canShowCallout = YES;
    return newAnnotation;
}


- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
    
}

-(void)centerMap:(MKMapView *)mapView
{
	MKCoordinateRegion region;
    
    CLLocationDegrees maxLat = -90;
	CLLocationDegrees maxLon = -180;
	CLLocationDegrees minLat = 90;
	CLLocationDegrees minLon = 180;
    
    
    for (id<MKAnnotation> annotation in mapView.annotations){
        if ([annotation isKindOfClass:[PlaceMark class]]) {
            PlaceMark *mark=(PlaceMark *)annotation;
            if(mark.coordinate.latitude > maxLat)
                maxLat = mark.coordinate.latitude;
            if(mark.coordinate.latitude < minLat)
                minLat = mark.coordinate.latitude;
            if(mark.coordinate.longitude > maxLon)
                maxLon = mark.coordinate.longitude;
            if(mark.coordinate.longitude < minLon)
                minLon = mark.coordinate.longitude;
        }
    }
	region.center.latitude     = (maxLat + minLat) / 2;
	region.center.longitude    = (maxLon + minLon) / 2;
	region.span.latitudeDelta  = (maxLat - minLat)+0.08;
	region.span.longitudeDelta = (maxLon - minLon)+0.08;
	
	[mapView setRegion:region animated:YES];
}


- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)annotationView
didChangeDragState:(MKAnnotationViewDragState)newState
   fromOldState:(MKAnnotationViewDragState)oldState
{
    if (newState == MKAnnotationViewDragStateEnding) {
        // custom code when drag ends...
        
        // tell the annotation view that the drag is done
        [annotationView setDragState:MKAnnotationViewDragStateNone animated:YES];
    }
    else if (newState == MKAnnotationViewDragStateCanceling) {
        // custom code when drag canceled...
        
        // tell the annotation view that the drag is done
        [annotationView setDragState:MKAnnotationViewDragStateNone animated:YES];
    }
}


#pragma mark -
#pragma mark - Memory Mgmt

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
