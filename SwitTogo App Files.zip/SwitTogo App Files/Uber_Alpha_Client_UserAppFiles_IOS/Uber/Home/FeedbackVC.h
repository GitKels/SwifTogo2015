//
//  FeedbackVC.h
//  Uber
//
//  Created by Elluminati - macbook on 09/07/14.
//  Copyright (c) 2014 Elluminati MacBook Pro 1. All rights reserved.
//

#import "BaseVC.h"

@interface FeedbackVC : BaseVC<UITextFieldDelegate>
{
    int rate;
}
@property(nonatomic,strong)ClientAssignment *clientAssignment;
@property(nonatomic,weak)IBOutlet UILabel *lblRefNo;
@property(nonatomic,weak)IBOutlet UITextField *txtComments;

+(FeedbackVC *)sharedObject;
-(IBAction)onClickBtnStar:(id)sender;
-(IBAction)onClickRateService:(id)sender;

@end
